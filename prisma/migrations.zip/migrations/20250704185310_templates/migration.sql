-- CreateEnum
CREATE TYPE "DocuTemplateFor" AS ENUM ('USER', 'ASHER');

-- AlterTable
ALTER TABLE "DocuTemplate" ADD COLUMN     "documentFor" "DocuTemplateFor" NOT NULL DEFAULT 'USER';
