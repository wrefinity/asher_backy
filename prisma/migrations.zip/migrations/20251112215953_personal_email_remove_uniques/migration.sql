-- DropIndex
DROP INDEX "applicantPersonalDetails_email_key";

-- AlterTable
ALTER TABLE "applicantPersonalDetails" ALTER COLUMN "email" DROP NOT NULL;
