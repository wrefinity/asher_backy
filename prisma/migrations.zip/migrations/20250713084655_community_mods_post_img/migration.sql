-- AlterTable
ALTER TABLE "Community" ALTER COLUMN "slug" DROP NOT NULL;
