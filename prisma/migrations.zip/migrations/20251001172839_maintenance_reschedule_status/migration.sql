-- CreateEnum
CREATE TYPE "maintenanceRescheduleStatus" AS ENUM ('PENDING', 'APPROVED', 'DECLINED');

-- AlterTable
ALTER TABLE "maintenance" ADD COLUMN     "isPaused" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "pauseResumeDate" TIMESTAMP(3),
ADD COLUMN     "rescheduleReason" TEXT,
ADD COLUMN     "rescheduleRequestDate" TIMESTAMP(3),
ADD COLUMN     "rescheduleRequestStatus" "maintenanceRescheduleStatus" DEFAULT 'PENDING';
