/*
  Warnings:

  - A unique constraint covering the columns `[ownerId]` on the table `Community` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "Community_ownerId_key" ON "Community"("ownerId");
