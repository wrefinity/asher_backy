-- AlterTable
ALTER TABLE "RoomDetail" ADD COLUMN     "count" INTEGER,
ADD COLUMN     "priceFrequency" "PriceFrequency",
ADD COLUMN     "unitId" TEXT,
ALTER COLUMN "isListed" SET DEFAULT false;

-- AlterTable
ALTER TABLE "UnitConfiguration" ADD COLUMN     "priceFrequency" "PriceFrequency",
ALTER COLUMN "isListed" SET DEFAULT false;

-- AlterTable
ALTER TABLE "properties" ADD COLUMN     "count" INTEGER;

-- AddForeignKey
ALTER TABLE "RoomDetail" ADD CONSTRAINT "RoomDetail_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "UnitConfiguration"("id") ON DELETE SET NULL ON UPDATE CASCADE;
