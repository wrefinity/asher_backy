-- AlterTable
ALTER TABLE "maintenance" ADD COLUMN     "endAttachments" TEXT[],
ADD COLUMN     "startAttachments" TEXT[];
