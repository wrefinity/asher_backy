-- AlterTable
ALTER TABLE "maintenance" ADD COLUMN     "roomId" TEXT,
ADD COLUMN     "unitId" TEXT;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "UnitConfiguration"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "RoomDetail"("id") ON DELETE SET NULL ON UPDATE CASCADE;
