-- CreateEnum
CREATE TYPE "ResponseType" AS ENUM ('FULL_PAYMENT', 'PARTIAL_PAYMENT', 'DISPUTE', 'FINANCIAL_HARDSHIP');

-- CreateTable
CREATE TABLE "ViolationResponse" (
    "id" TEXT NOT NULL,
    "violationId" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "responseType" "ResponseType" NOT NULL,
    "paymentAmount" DECIMAL(10,2),
    "paymentDate" TIMESTAMP(3),
    "paymentMethod" TEXT,
    "reasonForDispute" TEXT,
    "evidenceUrl" TEXT,
    "additionalComment" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "ViolationResponse_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "ViolationResponse" ADD CONSTRAINT "ViolationResponse_violationId_fkey" FOREIGN KEY ("violationId") REFERENCES "violation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ViolationResponse" ADD CONSTRAINT "ViolationResponse_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
