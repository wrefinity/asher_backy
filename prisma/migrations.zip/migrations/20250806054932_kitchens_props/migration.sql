-- AlterTable
ALTER TABLE "RoomDetail" ADD COLUMN     "furnished" BOOLEAN DEFAULT false;

-- AlterTable
ALTER TABLE "UnitConfiguration" ADD COLUMN     "ensuite" BOOLEAN DEFAULT false,
ADD COLUMN     "furnished" BOOLEAN DEFAULT false,
ADD COLUMN     "kitchens" INTEGER;
