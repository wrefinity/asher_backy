-- AlterTable
ALTER TABLE "RoomDetail" ADD COLUMN     "description" TEXT;
