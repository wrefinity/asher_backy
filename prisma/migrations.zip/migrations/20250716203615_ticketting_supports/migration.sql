/*
  Warnings:

  - You are about to drop the `landlordSupportTicket` table. If the table is not empty, all the data it contains will be lost.
  - You are about to drop the `tenantSupportTicket` table. If the table is not empty, all the data it contains will be lost.

*/
-- CreateEnum
CREATE TYPE "TicketType" AS ENUM ('SUPPORT', 'SUGGESTION');

-- CreateEnum
CREATE TYPE "TicketPriority" AS ENUM ('HIGH', 'MEDIUM', 'LOW', 'PENDING');

-- DropForeignKey
ALTER TABLE "landlordSupportTicket" DROP CONSTRAINT "landlordSupportTicket_landlordId_fkey";

-- DropForeignKey
ALTER TABLE "tenantSupportTicket" DROP CONSTRAINT "tenantSupportTicket_tenantId_fkey";

-- DropTable
DROP TABLE "landlordSupportTicket";

-- DropTable
DROP TABLE "tenantSupportTicket";

-- CreateTable
CREATE TABLE "SupportTicket" (
    "id" TEXT NOT NULL,
    "raisedById" TEXT NOT NULL,
    "assignedToId" TEXT,
    "type" "TicketType" NOT NULL DEFAULT 'SUPPORT',
    "subject" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "priority" "TicketPriority" NOT NULL DEFAULT 'PENDING',
    "status" "TicketStatus" NOT NULL DEFAULT 'OPEN',
    "attachments" TEXT[],
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SupportTicket_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "SupportTicket_raisedById_idx" ON "SupportTicket"("raisedById");

-- CreateIndex
CREATE INDEX "SupportTicket_assignedToId_idx" ON "SupportTicket"("assignedToId");

-- AddForeignKey
ALTER TABLE "SupportTicket" ADD CONSTRAINT "SupportTicket_raisedById_fkey" FOREIGN KEY ("raisedById") REFERENCES "landlords"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupportTicket" ADD CONSTRAINT "SupportTicket_assignedToId_fkey" FOREIGN KEY ("assignedToId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
