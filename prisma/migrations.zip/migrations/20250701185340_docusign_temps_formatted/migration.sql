-- AlterTable
ALTER TABLE "DocuTemplateVersion" ALTER COLUMN "content" SET DATA TYPE TEXT;
