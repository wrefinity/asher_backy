/*
  Warnings:

  - The `imageUrl` column on the `CommunityPost` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- AlterTable
ALTER TABLE "CommunityPost" ADD COLUMN     "videoUrl" TEXT[],
DROP COLUMN "imageUrl",
ADD COLUMN     "imageUrl" TEXT[];

-- CreateTable
CREATE TABLE "CommunityPostPoll" (
    "id" TEXT NOT NULL,
    "postId" TEXT NOT NULL,
    "question" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "CommunityPostPoll_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommunityPostPollOption" (
    "id" TEXT NOT NULL,
    "pollId" TEXT NOT NULL,
    "option" TEXT NOT NULL,
    "votes" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "CommunityPostPollOption_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommunityPostPollVote" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "optionId" TEXT NOT NULL,

    CONSTRAINT "CommunityPostPollVote_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "CommunityPostPoll_postId_key" ON "CommunityPostPoll"("postId");

-- CreateIndex
CREATE INDEX "CommunityPostPoll_postId_idx" ON "CommunityPostPoll"("postId");

-- CreateIndex
CREATE INDEX "CommunityPostPollOption_pollId_idx" ON "CommunityPostPollOption"("pollId");

-- CreateIndex
CREATE UNIQUE INDEX "CommunityPostPollVote_userId_optionId_key" ON "CommunityPostPollVote"("userId", "optionId");

-- AddForeignKey
ALTER TABLE "CommunityPostPoll" ADD CONSTRAINT "CommunityPostPoll_postId_fkey" FOREIGN KEY ("postId") REFERENCES "CommunityPost"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostPollOption" ADD CONSTRAINT "CommunityPostPollOption_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES "CommunityPostPoll"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostPollVote" ADD CONSTRAINT "CommunityPostPollVote_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostPollVote" ADD CONSTRAINT "CommunityPostPollVote_optionId_fkey" FOREIGN KEY ("optionId") REFERENCES "CommunityPostPollOption"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
