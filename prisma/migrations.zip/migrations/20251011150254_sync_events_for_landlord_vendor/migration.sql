-- AlterTable
ALTER TABLE "Event" ADD COLUMN     "color" TEXT DEFAULT 'blue',
ADD COLUMN     "landlordId" TEXT;

-- CreateIndex
CREATE INDEX "Event_landlordId_idx" ON "Event"("landlordId");

-- AddForeignKey
ALTER TABLE "Event" ADD CONSTRAINT "Event_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE CASCADE ON UPDATE CASCADE;
