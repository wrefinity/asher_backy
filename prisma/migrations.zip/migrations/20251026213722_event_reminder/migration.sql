-- AlterTable
ALTER TABLE "Event" ADD COLUMN     "reminder" BOOLEAN NOT NULL DEFAULT false;
