/*
  Warnings:

  - You are about to drop the `_CommunityToCommunityPost` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "_CommunityToCommunityPost" DROP CONSTRAINT "_CommunityToCommunityPost_A_fkey";

-- DropForeignKey
ALTER TABLE "_CommunityToCommunityPost" DROP CONSTRAINT "_CommunityToCommunityPost_B_fkey";

-- AlterTable
ALTER TABLE "CommunityPost" ADD COLUMN     "communityId" TEXT,
ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;

-- DropTable
DROP TABLE "_CommunityToCommunityPost";

-- AddForeignKey
ALTER TABLE "CommunityPost" ADD CONSTRAINT "CommunityPost_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "Community"("id") ON DELETE SET NULL ON UPDATE CASCADE;
