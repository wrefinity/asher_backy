/*
  Warnings:

  - You are about to drop the column `category` on the `Broadcast` table. All the data in the column will be lost.
  - You are about to drop the column `recipients` on the `Broadcast` table. All the data in the column will be lost.
  - Added the required column `categoryId` to the `Broadcast` table without a default value. This is not possible if the table is not empty.

*/
-- AlterTable
ALTER TABLE "Broadcast" DROP COLUMN "category",
DROP COLUMN "recipients",
ADD COLUMN     "categoryId" TEXT NOT NULL,
ADD COLUMN     "isDraft" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "scheduledAt" TIMESTAMP(3);

-- CreateTable
CREATE TABLE "BroadcastCategory" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "location" TEXT,
    "propertyId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BroadcastCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "BroadcastCategoryMembers" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "broadcastCategoryId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "BroadcastCategoryMembers_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "BroadcastCategoryMembers_userId_broadcastCategoryId_key" ON "BroadcastCategoryMembers"("userId", "broadcastCategoryId");

-- AddForeignKey
ALTER TABLE "Broadcast" ADD CONSTRAINT "Broadcast_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "BroadcastCategory"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BroadcastCategory" ADD CONSTRAINT "BroadcastCategory_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BroadcastCategoryMembers" ADD CONSTRAINT "BroadcastCategoryMembers_broadcastCategoryId_fkey" FOREIGN KEY ("broadcastCategoryId") REFERENCES "BroadcastCategory"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BroadcastCategoryMembers" ADD CONSTRAINT "BroadcastCategoryMembers_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;
