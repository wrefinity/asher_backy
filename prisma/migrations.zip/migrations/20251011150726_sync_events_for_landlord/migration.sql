/*
  Warnings:

  - You are about to drop the `LandlordEvent` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "LandlordEvent" DROP CONSTRAINT "LandlordEvent_landlordId_fkey";

-- DropTable
DROP TABLE "LandlordEvent";
