-- CreateEnum
CREATE TYPE "ApplicationStatus" AS ENUM ('PENDING', 'DECLINED', 'SUBMITTED', 'COMPLETED', 'AGREEMENTS', 'AGREEMENTS_SIGNED', 'LANDLORD_REFERENCE', 'GUARANTOR_REFERENCE', 'EMPLOYEE_REFERENCE', 'APPROVED', 'APPLICATION_FEE_PAID', 'MAKEPAYMENT', 'PAYMENT_COMPLETED', 'PAYMENT_PARTIALLY_COMPLETED', 'ACCEPTED', 'TENANT_CREATED');

-- CreateEnum
CREATE TYPE "AnswersEnum" AS ENUM ('YES', 'NO');

-- CreateEnum
CREATE TYPE "InvitedResponse" AS ENUM ('PENDING', 'RESCHEDULED', 'SCHEDULED', 'RESCHEDULED_ACCEPTED', 'RE_INVITED', 'VISITED', 'NOT_VISITED', 'REJECTED', 'ACCEPTED', 'AWAITING_FEEDBACK', 'FEEDBACK', 'COMPLETED', 'CANCELLED', 'APPLY', 'APPLICATION_STARTED', 'APPLICATION_NOT_STARTED', 'SUBMITTED', 'DECLINED', 'APPROVED', 'TENANT_CREATED', 'AGREEMENTS');

-- CreateEnum
CREATE TYPE "InvitedStatus" AS ENUM ('YES', 'NO');

-- CreateEnum
CREATE TYPE "ApplicationSaveState" AS ENUM ('PERSONAL_KIN', 'REFEREE', 'EMPLOYMENT', 'EMERGENCY_CONTACT', 'RESIDENTIAL_ADDRESS', 'DOCUMENT_UPLOAD', 'ADDITIONAL_INFO', 'GUARANTOR_INFO', 'DECLARATION');

-- CreateEnum
CREATE TYPE "BroadcastType" AS ENUM ('EMAIL', 'CHAT');

-- CreateEnum
CREATE TYPE "CategoryType" AS ENUM ('SERVICES', 'MAINTENANCE', 'BILL');

-- CreateEnum
CREATE TYPE "chatType" AS ENUM ('MAINTENANCE', 'APPLICATION', 'SUPPORT');

-- CreateEnum
CREATE TYPE "CommunityVisibility" AS ENUM ('PUBLIC', 'PRIVATE');

-- CreateEnum
CREATE TYPE "MembershipStatus" AS ENUM ('INVITED', 'MEMBER', 'REJECTED');

-- CreateEnum
CREATE TYPE "ComplaintCategory" AS ENUM ('MAINTENANCE', 'NOISY');

-- CreateEnum
CREATE TYPE "ComplaintPriority" AS ENUM ('LOW', 'MEDIUM', 'HIGH');

-- CreateEnum
CREATE TYPE "ComplaintStatus" AS ENUM ('IN_PROGRESS', 'RESOLVED');

-- CreateEnum
CREATE TYPE "DocumentType" AS ENUM ('PAY_STUB', 'TAX_RETURN', 'EMPLOYMENT_LETTER', 'CREDIT_REPORT', 'BACKGROUND_CHECK', 'LANDLORD_REFERENCE', 'BANK_STATEMENT', 'GUARANTOR_INCOME', 'GUARANTOR_EMPLOYMENT', 'REFEREE_CONFIRMATION', 'ID', 'ADDRESS_PROOF', 'INCOME_PROOF', 'ADDITIONAL', 'AGREEMENT_DOC', 'OTHER', 'FLOOR_PLAN', 'OWNERSHIP', 'INSURANCE');

-- CreateEnum
CREATE TYPE "IdType" AS ENUM ('PASSPORT', 'DRIVING_LICENSE');

-- CreateEnum
CREATE TYPE "MediaType" AS ENUM ('IMAGE', 'VIDEO', 'VIRTUAL_TOUR');

-- CreateEnum
CREATE TYPE "LogType" AS ENUM ('MAINTENANCE', 'APPLICATION', 'TRANSACTION', 'FEEDBACK', 'ACTIVITY', 'VIEW', 'ENQUIRED', 'CALL', 'MESSAGE', 'EMAIL');

-- CreateEnum
CREATE TYPE "logTypeStatus" AS ENUM ('PENDING', 'INVITED', 'RE_INVITED', 'REJECTED', 'COMPLETED');

-- CreateEnum
CREATE TYPE "maintenanceStatus" AS ENUM ('ASSIGNED', 'UNASSIGNED', 'PENDING', 'COMPLETED', 'CANCELLATION_REQUEST', 'CANCEL');

-- CreateEnum
CREATE TYPE "maintenanceDecisionStatus" AS ENUM ('APPROVED', 'DECLINED', 'PENDING');

-- CreateEnum
CREATE TYPE "vendorAvailability" AS ENUM ('YES', 'NO');

-- CreateEnum
CREATE TYPE "RiskLevel" AS ENUM ('EXCELLENT', 'GOOD', 'FAIR', 'POOR', 'CRITICAL');

-- CreateEnum
CREATE TYPE "LatePaymentFeeType" AS ENUM ('ONE_TIME', 'DAILY', 'WEEKLY');

-- CreateEnum
CREATE TYPE "PriceFrequency" AS ENUM ('DAILY', 'WEEKLY', 'MONTHLY', 'QUARTERLY', 'ANNUALLY', 'PER_SQFT');

-- CreateEnum
CREATE TYPE "TensureType" AS ENUM ('FREEHOLD', 'LEASE_HOLD', 'SHARE_OR_FREEHOLD', 'COMMONHOLD');

-- CreateEnum
CREATE TYPE "GarageType" AS ENUM ('ATTACHED_GARAGE', 'DETACHED_GARAGE', 'INTEGRAL_GARAGE');

-- CreateEnum
CREATE TYPE "VatStatus" AS ENUM ('VAT_EXEMPT', 'VAT_APPLICABLE', 'VAT_OPTIONAL');

-- CreateEnum
CREATE TYPE "PropertyType" AS ENUM ('SINGLE_UNIT', 'MULTI_UNIT', 'HOUSE', 'HOUSE_MULTIPLE_OCCUPATION', 'SHARED_HOUSE', 'RENTAL_ROOM', 'APARTMENT', 'VILLA', 'CONDOMINIUM', 'STUDIO', 'PENTHOUSE', 'BUNGALOW', 'DUPLEX', 'TOWNHOUSE', 'COTTAGE', 'LOFT', 'CHALET', 'OFFICE_SPACE', 'RETAIL_SPACE', 'WAREHOUSE', 'INDUSTRIAL_UNIT', 'LEISURE_FACILITY', 'HOTEL', 'RESTUARANT_CAFE', 'MIXED_USE_BUILDING', 'COMMERCIAL_LAND', 'CO_WORKING_SPACE', 'SERVICED_OFFICE', 'WORKSHOP', 'HIGH_RISE_COMMERCIAL_BUILDING', 'HIGH_RISE_BUILDING', 'MEDICAL_FACILITY', 'STORAGE_FACILITY', 'EDUCATIONAL_FACILITY', 'SHOW_ROOM', 'COMMERICAL_GARAGE', 'BUSINESS_PARK_UNIT', 'DATA_CENTER', 'OTHER');

-- CreateEnum
CREATE TYPE "PropertyStatus" AS ENUM ('FOR_SALE', 'FOR_RENT', 'SOLD', 'RENTED');

-- CreateEnum
CREATE TYPE "GlazingType" AS ENUM ('SINGLE_GLAZING', 'DOUBLE_GLAZING', 'TRIPLE_GLAZING', 'SECONDARY_GLAZING', 'MIXED_GLAZING');

-- CreateEnum
CREATE TYPE "PropertySpecificationType" AS ENUM ('COMMERCIAL', 'RESIDENTIAL', 'SHORTLET');

-- CreateEnum
CREATE TYPE "AvailabilityStatus" AS ENUM ('OCCUPIED', 'VACANT', 'RENTED', 'RESERVED', 'COMING_SOON', 'SOLD', 'PENDING', 'MAINTENANCE');

-- CreateEnum
CREATE TYPE "Currency" AS ENUM ('NGN', 'USD', 'EUR', 'GBP');

-- CreateEnum
CREATE TYPE "LeaseTermUnit" AS ENUM ('DAYS', 'WEEKS', 'MONTHS', 'YEARS');

-- CreateEnum
CREATE TYPE "AreaUnit" AS ENUM ('SQFT', 'SQM');

-- CreateEnum
CREATE TYPE "BookingStatus" AS ENUM ('PENDING', 'CONFIRMED', 'CANCELLED', 'COMPLETED');

-- CreateEnum
CREATE TYPE "OfficeLayout" AS ENUM ('OPEN_PLAN', 'CELLULAR', 'MIXED');

-- CreateEnum
CREATE TYPE "BuildingClass" AS ENUM ('A', 'B', 'C', 'D');

-- CreateEnum
CREATE TYPE "CancellationPolicy" AS ENUM ('FLEXIBLE', 'MODERATE', 'STRICT', 'NON_REFUNDABLE', 'CUSTOM');

-- CreateEnum
CREATE TYPE "PropsSettingType" AS ENUM ('NOT_DEFINED', 'APPLICATION', 'SECURITY_DEPOSIT', 'LATEFEE');

-- CreateEnum
CREATE TYPE "Refundability" AS ENUM ('YES', 'NO');

-- CreateEnum
CREATE TYPE "ListingType" AS ENUM ('SINGLE_UNIT', 'ROOM', 'ENTIRE_PROPERTY', 'SHARED_ROOM', 'BED_SPACE', 'CO_TENANCY');

-- CreateEnum
CREATE TYPE "PropertyFeatureType" AS ENUM ('SECURITY', 'KEY', 'SAFETY', 'AMENITY', 'OFFICE_AMENITY', 'BUILDING_AMENITY', 'OUTDOORS_SPACE');

-- CreateEnum
CREATE TYPE "StatusType" AS ENUM ('PENDING', 'COMPLETED', 'IN_PROGRESS');

-- CreateEnum
CREATE TYPE "PriorityType" AS ENUM ('LOW', 'HIGH', 'MEDIUM');

-- CreateEnum
CREATE TYPE "InventoryType" AS ENUM ('UNAVIALABLE', 'AVAILABLE', 'UNDER_MAINTANACE');

-- CreateEnum
CREATE TYPE "ReferenceStatus" AS ENUM ('PENDING', 'COMPLETED', 'DRAFT', 'SUBMITTED', 'APPROVED', 'REJECTED');

-- CreateEnum
CREATE TYPE "EmploymentType" AS ENUM ('EMPLOYED', 'SELF_EMPLOYED', 'FREELANCE', 'DIRECTOR', 'SOLE_PROPRIETOR');

-- CreateEnum
CREATE TYPE "ReviewType" AS ENUM ('FEEDBACK', 'NORMAL_REVIEW');

-- CreateEnum
CREATE TYPE "YesNo" AS ENUM ('YES', 'NO');

-- CreateEnum
CREATE TYPE "userRoles" AS ENUM ('VENDOR', 'LANDLORD', 'TENANT', 'WEBUSER', 'AGENT', 'ADMIN');

-- CreateEnum
CREATE TYPE "SettingType" AS ENUM ('SECURITY_DEPOSIT', 'APPLICATION_FEE', 'RECURRING_FEE');

-- CreateEnum
CREATE TYPE "TicketStatus" AS ENUM ('OPEN', 'IN_PROGRESS', 'RESOLVED', 'CLOSED');

-- CreateEnum
CREATE TYPE "TransactionReference" AS ENUM ('FUND_WALLET', 'WITHDRAWAL', 'MAKE_PAYMENT', 'RECEIVE_PAYMENT', 'RENT_DUE', 'RENT_PAYMENT', 'MAINTENANCE_FEE', 'LANDLORD_PAYOUT', 'BILL_PAYMENT', 'LATE_FEE', 'CHARGES', 'SUPPLIES', 'EQUIPMENTS');

-- CreateEnum
CREATE TYPE "TransactionType" AS ENUM ('CREDIT', 'DEBIT');

-- CreateEnum
CREATE TYPE "TransactionStatus" AS ENUM ('PENDING', 'COMPLETED', 'FAILED', 'RENT_RENEWED');

-- CreateEnum
CREATE TYPE "PaymentGateway" AS ENUM ('STRIPE', 'FLUTTERWAVE', 'PAYSTACK');

-- CreateEnum
CREATE TYPE "PaymentFrequency" AS ENUM ('DAILY', 'WEEKLY', 'MONTHLY', 'YEARLY', 'QUARTERLY', 'ANNUALLY', 'PER_SQFT');

-- CreateEnum
CREATE TYPE "PayableBy" AS ENUM ('LANDLORD', 'TENANT');

-- CreateEnum
CREATE TYPE "BudgetFrequency" AS ENUM ('WEEKLY', 'MONTHLY', 'ANNUAL');

-- CreateEnum
CREATE TYPE "onlineStatus" AS ENUM ('online', 'offline');

-- CreateEnum
CREATE TYPE "SeverityLevel" AS ENUM ('LOW', 'MODERATE', 'SEVERE', 'CRITICAL', 'EXTREME');

-- CreateEnum
CREATE TYPE "NoticeType" AS ENUM ('LEASE_EVICTION', 'PAY_OR_OUT', 'OTHER');

-- CreateEnum
CREATE TYPE "DeliveryMethod" AS ENUM ('IN_PERSON', 'CERTIFIED_MAIL', 'PROPERTY_POSTING', 'EMAIL', 'PROCESS_SERVER');

-- CreateEnum
CREATE TYPE "ViolationStatus" AS ENUM ('PENDING');

-- CreateEnum
CREATE TYPE "LeaseBreachType" AS ENUM ('SUBLETTING', 'ILLEGAL_ACTIVITY', 'UNAUTHORIZED_BUSINESS', 'UNAUTHORIZED_OCCUPANT', 'PROPERTY_DAMAGE', 'SMOKING_VIOLATION', 'NOISE_VIOLATION', 'PARKING_VIOLATION', 'TRASH_VIOLATION', 'UNAUTHORIZED_PET', 'LATE_PAYMENT', 'GUEST_VIOLATION', 'INSURANCE_LAPSE', 'MAINTENANCE_NEGLECT', 'OTHER');

-- CreateTable
CREATE TABLE "applicationInvites" (
    "id" TEXT NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "applicationFee" "YesNo",
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "scheduleDate" TIMESTAMP(3),
    "reScheduleDate" TIMESTAMP(3),
    "response" "InvitedResponse" NOT NULL DEFAULT 'PENDING',
    "responseStepsCompleted" "InvitedResponse"[],
    "propertiesId" TEXT,
    "invitedByLandordId" TEXT,
    "tenantsId" TEXT,
    "userInvitedId" TEXT,
    "enquiryId" TEXT,

    CONSTRAINT "applicationInvites_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "application" (
    "id" TEXT NOT NULL,
    "completedSteps" "ApplicationSaveState"[],
    "lastStep" "ApplicationSaveState" DEFAULT 'PERSONAL_KIN',
    "leaseStartDate" TIMESTAMP(3),
    "leaseEndDate" TIMESTAMP(3),
    "propertyType" TEXT,
    "moveInDate" TIMESTAMP(3),
    "rentAmountPaid" DECIMAL(65,30),
    "securityDeposit" DECIMAL(65,30),
    "leaseTerm" TEXT,
    "status" "ApplicationStatus" NOT NULL DEFAULT 'PENDING',
    "statuesCompleted" "ApplicationStatus"[],
    "invited" "InvitedStatus" DEFAULT 'NO',
    "stepCompleted" INTEGER DEFAULT 1,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT,
    "residentialId" TEXT,
    "emergencyContactId" TEXT,
    "employmentInformationId" TEXT,
    "propertiesId" TEXT,
    "applicantPersonalDetailsId" TEXT NOT NULL,
    "guarantorInformationId" TEXT,
    "refereeId" TEXT,
    "createdById" TEXT,
    "updatedById" TEXT,
    "applicationInviteId" TEXT,
    "employmentVerificationStatus" "YesNo",
    "incomeVerificationStatus" "YesNo",
    "creditCheckStatus" "YesNo",
    "landlordVerificationStatus" "YesNo",
    "guarantorVerificationStatus" "YesNo",
    "refereeVerificationStatus" "YesNo",
    "agreementDocumentUrl" TEXT[],
    "agreementVersion" INTEGER NOT NULL DEFAULT 1,
    "lastAgreementUpdate" TIMESTAMP(3),

    CONSTRAINT "application_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "applicantPersonalDetails" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "firstName" TEXT NOT NULL,
    "middleName" TEXT,
    "lastName" TEXT NOT NULL,
    "dob" TIMESTAMP(3) NOT NULL,
    "email" TEXT,
    "phoneNumber" TEXT NOT NULL,
    "maritalStatus" TEXT NOT NULL,
    "nationality" TEXT,
    "identificationType" TEXT,
    "identificationNo" TEXT,
    "issuingAuthority" TEXT,
    "expiryDate" TIMESTAMP(3) NOT NULL,
    "userId" TEXT,

    CONSTRAINT "applicantPersonalDetails_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "nextOfKin" (
    "id" TEXT NOT NULL,
    "lastName" TEXT NOT NULL,
    "relationship" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "firstName" TEXT NOT NULL,
    "phoneNumber" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "middleName" TEXT,
    "applicantPersonalDetailsId" TEXT,
    "userId" TEXT NOT NULL,

    CONSTRAINT "nextOfKin_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PrevAddress" (
    "id" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "lengthOfResidence" TEXT NOT NULL,
    "residentialInformationId" TEXT,

    CONSTRAINT "PrevAddress_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "residentialInformation" (
    "id" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "addressStatus" TEXT NOT NULL,
    "city" TEXT,
    "state" TEXT,
    "country" TEXT,
    "zipCode" TEXT,
    "lengthOfResidence" TEXT NOT NULL,
    "reasonForLeaving" TEXT,
    "landlordOrAgencyPhoneNumber" TEXT NOT NULL,
    "landlordOrAgencyEmail" TEXT NOT NULL,
    "landlordOrAgencyName" TEXT NOT NULL,
    "userId" TEXT,

    CONSTRAINT "residentialInformation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "guarantorInformation" (
    "id" TEXT NOT NULL,
    "fullName" TEXT NOT NULL,
    "phoneNumber" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "relationship" TEXT,
    "identificationType" TEXT,
    "identificationNo" TEXT,
    "monthlyIncome" TEXT,
    "employerName" TEXT,
    "userId" TEXT,
    "dateOfBirth" TIMESTAMP(3),
    "nationalInsuranceNumber" TEXT,
    "title" TEXT,

    CONSTRAINT "guarantorInformation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "emergencyContact" (
    "id" TEXT NOT NULL,
    "fullname" TEXT NOT NULL,
    "phoneNumber" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "address" TEXT NOT NULL,
    "userId" TEXT,

    CONSTRAINT "emergencyContact_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "referees" (
    "id" TEXT NOT NULL,
    "professionalReferenceName" TEXT NOT NULL,
    "personalReferenceName" TEXT NOT NULL,
    "personalEmail" TEXT NOT NULL,
    "professionalEmail" TEXT NOT NULL,
    "personalPhoneNumber" TEXT NOT NULL,
    "professionalPhoneNumber" TEXT NOT NULL,
    "personalRelationship" TEXT NOT NULL,
    "professionalRelationship" TEXT NOT NULL,
    "userId" TEXT,

    CONSTRAINT "referees_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmploymentInformation" (
    "id" TEXT NOT NULL,
    "employmentStatus" TEXT NOT NULL,
    "taxCredit" TEXT,
    "startDate" TIMESTAMP(3),
    "zipCode" TEXT,
    "address" TEXT,
    "city" TEXT,
    "state" TEXT,
    "country" TEXT,
    "monthlyOrAnualIncome" TEXT,
    "childBenefit" TEXT,
    "childMaintenance" TEXT,
    "disabilityBenefit" TEXT,
    "housingBenefit" TEXT,
    "others" TEXT,
    "pension" TEXT,
    "moreDetails" TEXT,
    "employerCompany" TEXT,
    "employerEmail" TEXT,
    "employerPhone" TEXT,
    "positionTitle" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT,

    CONSTRAINT "EmploymentInformation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "applicationQuestions" (
    "id" TEXT NOT NULL,
    "havePet" "AnswersEnum" DEFAULT 'NO',
    "youSmoke" "AnswersEnum" DEFAULT 'NO',
    "requireParking" "AnswersEnum" DEFAULT 'NO',
    "haveOutstandingDebts" "AnswersEnum" DEFAULT 'NO',
    "additionalOccupants" TEXT,
    "additionalInformation" TEXT,
    "applicantId" TEXT NOT NULL,

    CONSTRAINT "applicationQuestions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "declaration" (
    "id" TEXT NOT NULL,
    "signature" TEXT,
    "declaration" TEXT NOT NULL,
    "additionalNotes" TEXT,
    "date" TIMESTAMP(3) NOT NULL,
    "applicantId" TEXT,

    CONSTRAINT "declaration_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Broadcast" (
    "id" TEXT NOT NULL,
    "landlordId" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "type" "BroadcastType" NOT NULL,
    "recipients" TEXT[],
    "category" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Broadcast_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "category" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "image" TEXT[],
    "labels" TEXT[],
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "categoryType" "CategoryType",

    CONSTRAINT "category_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "subCategory" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "description" TEXT,
    "image" TEXT[],
    "labels" TEXT[],
    "type" "CategoryType" NOT NULL DEFAULT 'MAINTENANCE',
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "categoryId" TEXT NOT NULL,

    CONSTRAINT "subCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Message" (
    "id" TEXT NOT NULL,
    "content" TEXT,
    "senderId" TEXT NOT NULL,
    "receiverId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "chatRoomId" TEXT NOT NULL,
    "images" TEXT[],
    "audios" TEXT[],
    "files" TEXT[],
    "videos" TEXT[],
    "chatType" "chatType",

    CONSTRAINT "Message_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ChatRoom" (
    "id" TEXT NOT NULL,
    "user1Id" TEXT NOT NULL,
    "user2Id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "maintenanceId" TEXT,

    CONSTRAINT "ChatRoom_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Community" (
    "id" TEXT NOT NULL,
    "communityName" TEXT NOT NULL,
    "communityOwnerId" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "visibility" "CommunityVisibility" NOT NULL DEFAULT 'PUBLIC',
    "communityProfileImage" TEXT,
    "communityProfileUrl" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Community_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommunityMember" (
    "id" TEXT NOT NULL,
    "communityId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "status" "MembershipStatus" NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "CommunityMember_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommunityInvitationLink" (
    "id" TEXT NOT NULL,
    "communityId" TEXT NOT NULL,
    "inviteCode" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CommunityInvitationLink_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommunityPost" (
    "id" TEXT NOT NULL,
    "communityId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "tags" TEXT[],
    "content" TEXT NOT NULL,
    "imageUrl" TEXT,
    "likesCount" INTEGER NOT NULL DEFAULT 0,
    "viewsCount" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "CommunityPost_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommunityPostLikes" (
    "id" TEXT NOT NULL,
    "postId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CommunityPostLikes_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommunityPostViews" (
    "id" TEXT NOT NULL,
    "postId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,

    CONSTRAINT "CommunityPostViews_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Comments" (
    "id" TEXT NOT NULL,
    "postId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "comment" TEXT NOT NULL,
    "parentCommentId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Comments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Complaint" (
    "id" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "category" "ComplaintCategory" NOT NULL DEFAULT 'MAINTENANCE',
    "subject" TEXT NOT NULL,
    "createdById" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "propertyId" TEXT,
    "priority" "ComplaintPriority" NOT NULL DEFAULT 'LOW',
    "status" "ComplaintStatus" NOT NULL DEFAULT 'IN_PROGRESS',

    CONSTRAINT "Complaint_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "propertyDocument" (
    "id" TEXT NOT NULL,
    "documentName" TEXT NOT NULL,
    "documentUrl" TEXT[],
    "size" TEXT,
    "type" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "idType" "IdType",
    "docType" "DocumentType",
    "agreementId" TEXT,
    "applicationId" TEXT,
    "propertyId" TEXT,
    "uploadedBy" TEXT,

    CONSTRAINT "propertyDocument_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PropertyMediaFiles" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "url" TEXT NOT NULL,
    "caption" TEXT,
    "isPrimary" BOOLEAN NOT NULL DEFAULT false,
    "fileType" TEXT,
    "type" "MediaType" NOT NULL,
    "image_property_id" TEXT,
    "video_property_id" TEXT,
    "virtual_tour_property_id" TEXT,

    CONSTRAINT "PropertyMediaFiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Email" (
    "id" TEXT NOT NULL,
    "senderEmail" TEXT NOT NULL,
    "receiverEmail" TEXT NOT NULL,
    "subject" TEXT,
    "body" TEXT NOT NULL,
    "attachment" TEXT[],
    "isReadBySender" BOOLEAN NOT NULL DEFAULT true,
    "isReadByReceiver" BOOLEAN NOT NULL DEFAULT false,
    "isDraft" BOOLEAN NOT NULL DEFAULT true,
    "isSent" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "senderId" TEXT NOT NULL,
    "receiverId" TEXT NOT NULL,

    CONSTRAINT "Email_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inspection" (
    "id" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "notes" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inspection_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Log" (
    "id" TEXT NOT NULL,
    "subjects" TEXT,
    "viewAgain" "YesNo",
    "considerRenting" "YesNo",
    "events" TEXT NOT NULL,
    "type" "LogType",
    "status" "logTypeStatus",
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "propertyId" TEXT,
    "applicationId" TEXT,
    "transactionId" TEXT,
    "createdById" TEXT,

    CONSTRAINT "Log_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "maintenance" (
    "id" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "attachments" TEXT[],
    "offer" TEXT[],
    "scheduleDate" TIMESTAMP(3),
    "reScheduleMax" INTEGER DEFAULT 1,
    "reScheduleDate" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "handleByLandlord" BOOLEAN NOT NULL DEFAULT false,
    "landlordDecision" "maintenanceDecisionStatus",
    "cancelReason" TEXT,
    "flagCancellation" BOOLEAN DEFAULT false,
    "vendorConsentCancellation" BOOLEAN,
    "tenantId" TEXT,
    "landlordId" TEXT,
    "vendorId" TEXT,
    "propertyId" TEXT,
    "categoryId" TEXT NOT NULL,
    "chatRoomId" TEXT,
    "status" "maintenanceStatus" NOT NULL DEFAULT 'UNASSIGNED',
    "serviceId" TEXT,
    "paymentStatus" "TransactionStatus" NOT NULL DEFAULT 'PENDING',
    "amount" DECIMAL(18,2),

    CONSTRAINT "maintenance_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "maintenanceRescheduleHistory" (
    "id" TEXT NOT NULL,
    "maintenanceId" TEXT NOT NULL,
    "oldDate" TIMESTAMP(3) NOT NULL,
    "newDate" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "maintenanceRescheduleHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "services" (
    "id" TEXT NOT NULL,
    "currentJobs" INTEGER NOT NULL DEFAULT 0,
    "availability" "vendorAvailability" NOT NULL DEFAULT 'YES',
    "standardPriceRange" TEXT NOT NULL,
    "mediumPriceRange" TEXT NOT NULL,
    "premiumPriceRange" TEXT NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "vendorId" TEXT NOT NULL,
    "categoryId" TEXT,
    "subcategoryId" TEXT,
    "tenantId" TEXT,

    CONSTRAINT "services_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "maintenanceWhitelist" (
    "id" TEXT NOT NULL,
    "categoryId" TEXT NOT NULL,
    "subcategoryId" TEXT,
    "landlordId" TEXT NOT NULL,
    "propertyId" TEXT,
    "isActive" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "maintenanceWhitelist_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "profile" (
    "id" TEXT NOT NULL,
    "gender" TEXT,
    "phoneNumber" TEXT,
    "address" TEXT,
    "country" TEXT,
    "city" TEXT,
    "maritalStatus" TEXT,
    "dateOfBirth" TIMESTAMP(3),
    "fullname" TEXT,
    "firstName" TEXT,
    "lastName" TEXT,
    "middleName" TEXT,
    "profileUrl" TEXT,
    "zip" TEXT,
    "unit" TEXT,
    "state" TEXT,
    "timeZone" TEXT,
    "taxPayerId" TEXT,
    "taxType" TEXT,
    "title" TEXT,

    CONSTRAINT "profile_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "propertyListingHistory" (
    "id" TEXT NOT NULL,
    "payApplicationFee" BOOLEAN NOT NULL DEFAULT false,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "onListing" BOOLEAN NOT NULL DEFAULT true,
    "type" "ListingType" DEFAULT 'SINGLE_UNIT',
    "propertyId" TEXT,
    "listAs" "PropertySpecificationType" DEFAULT 'SHORTLET',
    "propertySubType" "PropertyType",
    "unitId" TEXT,
    "roomId" TEXT,
    "price" DECIMAL(18,2) DEFAULT 0.00,
    "priceFrequency" "PriceFrequency",
    "securityDeposit" DECIMAL(18,2) DEFAULT 0.00,
    "minStayDays" INTEGER,
    "maxStayDays" INTEGER,
    "createdAt" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
    "availableFrom" TIMESTAMP(3),
    "availableTo" TIMESTAMP(3),

    CONSTRAINT "propertyListingHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SuitableUse" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "commercialPropertyId" TEXT NOT NULL,

    CONSTRAINT "SuitableUse_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AdditionalRule" (
    "id" TEXT NOT NULL,
    "rule" TEXT NOT NULL,
    "shortletId" TEXT NOT NULL,

    CONSTRAINT "AdditionalRule_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UnavailableDate" (
    "id" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "shortletId" TEXT NOT NULL,

    CONSTRAINT "UnavailableDate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HostLanguage" (
    "id" TEXT NOT NULL,
    "language" TEXT NOT NULL,
    "shortletId" TEXT NOT NULL,

    CONSTRAINT "HostLanguage_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "properties" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3),
    "name" TEXT NOT NULL,
    "description" TEXT,
    "shortDescription" TEXT,
    "propertySize" INTEGER,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "landlordId" TEXT NOT NULL,
    "agencyId" TEXT,
    "marketValue" DECIMAL(18,2) DEFAULT 0.00,
    "price" DECIMAL(18,2) DEFAULT 0.00,
    "initialDeposit" DECIMAL(18,2) DEFAULT 0.00,
    "securityDeposit" DECIMAL(18,2) DEFAULT 0.00,
    "areaUnit" "AreaUnit" NOT NULL DEFAULT 'SQFT',
    "yearBuilt" INTEGER,
    "city" TEXT NOT NULL,
    "stateId" TEXT NOT NULL,
    "country" TEXT NOT NULL,
    "zipcode" TEXT NOT NULL,
    "longitude" DECIMAL(18,6),
    "latitude" DECIMAL(18,6),
    "address" TEXT NOT NULL,
    "address2" TEXT,
    "currency" "Currency" DEFAULT 'NGN',
    "priceFrequency" "PriceFrequency",
    "rentalPeriod" TEXT,
    "availability" "AvailabilityStatus" DEFAULT 'VACANT',
    "businessRateVerified" BOOLEAN NOT NULL DEFAULT false,
    "postalCodeVerified" BOOLEAN NOT NULL DEFAULT false,
    "landRegistryNumber" TEXT,
    "vatStatus" "VatStatus" DEFAULT 'VAT_EXEMPT',
    "specificationType" "PropertySpecificationType" DEFAULT 'RESIDENTIAL',
    "contactName" TEXT,
    "contactCompany" TEXT,
    "companyLogoUrl" TEXT,
    "viewingArrangements" TEXT,
    "keyFeatures" TEXT[],
    "customKeyFeatures" TEXT[],
    "nearbyAmenities" TEXT[],
    "customNearbyAmenities" TEXT[],
    "amenityDistances" JSONB,

    CONSTRAINT "properties_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PropertySpecification" (
    "id" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "specificationType" "PropertySpecificationType" NOT NULL,
    "propertySubType" "PropertyType",
    "otherTypeSpecific" JSONB,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "fromDate" TIMESTAMP(3),
    "toDate" TIMESTAMP(3),
    "residentialId" TEXT,
    "commercialId" TEXT,
    "shortletId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "PropertySpecification_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SharedFacilities" (
    "id" TEXT NOT NULL,
    "kitchen" BOOLEAN NOT NULL DEFAULT false,
    "bathroom" BOOLEAN NOT NULL DEFAULT false,
    "livingRoom" BOOLEAN NOT NULL DEFAULT false,
    "garden" BOOLEAN NOT NULL DEFAULT false,
    "garage" BOOLEAN NOT NULL DEFAULT false,
    "laundry" BOOLEAN NOT NULL DEFAULT false,
    "parking" BOOLEAN NOT NULL DEFAULT false,
    "other" TEXT,
    "residentialPropertyId" TEXT,
    "commercialPropertyId" TEXT,
    "shortletPropertyId" TEXT,

    CONSTRAINT "SharedFacilities_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UnitConfiguration" (
    "id" TEXT NOT NULL,
    "unitType" TEXT NOT NULL,
    "unitNumber" TEXT,
    "floorNumber" INTEGER,
    "count" INTEGER,
    "bedrooms" INTEGER,
    "bathrooms" INTEGER,
    "price" TEXT NOT NULL,
    "area" TEXT,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "isListed" BOOLEAN NOT NULL DEFAULT true,
    "description" TEXT,
    "availability" "AvailabilityStatus",
    "residentialPropertyId" TEXT,
    "commercialPropertyId" TEXT,

    CONSTRAINT "UnitConfiguration_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "RoomDetail" (
    "id" TEXT NOT NULL,
    "roomName" TEXT NOT NULL,
    "roomSize" TEXT NOT NULL,
    "ensuite" BOOLEAN NOT NULL DEFAULT false,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "price" TEXT NOT NULL,
    "availability" "AvailabilityStatus" DEFAULT 'VACANT',
    "isListed" BOOLEAN NOT NULL DEFAULT true,
    "residentialPropertyId" TEXT,
    "commercialPropertyId" TEXT,
    "shortletPropertyId" TEXT,

    CONSTRAINT "RoomDetail_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ResidentialProperty" (
    "id" TEXT NOT NULL,
    "status" "PropertyStatus" NOT NULL DEFAULT 'FOR_RENT',
    "bedrooms" INTEGER,
    "bathrooms" INTEGER,
    "receiptionRooms" INTEGER,
    "toilets" INTEGER,
    "tenure" "TensureType",
    "furnished" BOOLEAN,
    "renovationYear" TEXT,
    "councilTaxBand" TEXT,
    "parkingSpaces" INTEGER NOT NULL DEFAULT 0,
    "garageType" "GarageType",
    "yearBuilt" INTEGER,
    "floorLevel" INTEGER,
    "totalArea" TEXT,
    "areaUnit" "AreaUnit",
    "petPolicy" TEXT,
    "rentalTerms" TEXT,
    "utilities" TEXT[],
    "garden" TEXT,
    "gardenSize" TEXT,
    "houseStyle" TEXT,
    "numberOfStories" TEXT,
    "outdoorsSpacesFeatures" TEXT[],
    "otherSharedFacilities" TEXT[],
    "houseRule" TEXT,
    "maxOccupant" INTEGER,
    "isHMO" BOOLEAN,
    "isShareHouse" BOOLEAN,
    "isHMOLicenced" BOOLEAN,
    "hmoLicenceNumber" TEXT,
    "hmoLicenceExpiryDate" TIMESTAMP(3),
    "totalOccupants" INTEGER,
    "occupantsDetails" TEXT,
    "totalFloors" INTEGER,
    "unitPerFloors" INTEGER,
    "totalUnits" INTEGER,
    "buildingAmenityFeatures" TEXT[],
    "safetyFeatures" TEXT[],
    "customSafetyFeatures" TEXT[],
    "epcRating" TEXT,
    "energyEfficiencyRating" INTEGER,
    "environmentalImpactRating" INTEGER,
    "heatingTypes" TEXT[],
    "coolingTypes" TEXT[],
    "glazingTypes" "GlazingType",
    "additionalNotes" TEXT,

    CONSTRAINT "ResidentialProperty_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommercialProperty" (
    "id" TEXT NOT NULL,
    "totalArea" TEXT NOT NULL,
    "areaUnit" "AreaUnit" NOT NULL,
    "businessRates" TEXT,
    "serviceCharge" DOUBLE PRECISION,
    "leaseTermUnit" "LeaseTermUnit" NOT NULL,
    "minimumLeaseTerm" INTEGER NOT NULL,
    "maximumLeaseTerm" INTEGER,
    "buildingClass" "BuildingClass",
    "lastRefurbished" TEXT,
    "totalFloors" INTEGER,
    "zoning" TEXT,
    "yearBuilt" INTEGER,
    "totalRooms" INTEGER NOT NULL,
    "parkingSpaces" INTEGER NOT NULL DEFAULT 0,
    "floorLevel" INTEGER,
    "availableFrom" TIMESTAMP(3),
    "floorNumber" INTEGER,
    "workstations" INTEGER,
    "meetingRooms" INTEGER,
    "officeLayout" "OfficeLayout",
    "highRiseFloors" INTEGER,
    "securityFeatures" TEXT[],
    "clearHeight" TEXT,
    "loadingDoorsCount" INTEGER,
    "powerSupply" TEXT,
    "floorLoad" TEXT,
    "columnSpacing" TEXT,
    "hasYard" BOOLEAN NOT NULL DEFAULT false,
    "yardDepth" TEXT,
    "safetyFeatures" TEXT[],
    "customSafetyFeatures" TEXT[],
    "epcRating" TEXT,
    "energyEfficiencyRating" INTEGER,
    "environmentalImpactRating" INTEGER,
    "heatingTypes" TEXT[],
    "coolingTypes" TEXT[],
    "hasGreenCertification" BOOLEAN NOT NULL DEFAULT false,
    "greenCertificationType" TEXT,
    "greenCertificationLevel" TEXT,
    "totalUnits" INTEGER,
    "leaseTerm" TEXT,
    "leaseTermNegotiable" BOOLEAN NOT NULL DEFAULT true,
    "rentReviewPeriod" TEXT,
    "breakClause" TEXT,
    "rentFreeOffered" BOOLEAN NOT NULL DEFAULT false,
    "rentFreePeriod" TEXT,
    "otherSharedFacilities" TEXT[],
    "houseRule" TEXT,
    "maxOccupant" INTEGER,
    "isHMO" BOOLEAN,
    "isShareHouse" BOOLEAN,
    "isHMOLicenced" BOOLEAN,
    "hmoLicenceNumber" TEXT,
    "hmoLicenceExpiryDate" TIMESTAMP(3),
    "totalOccupants" INTEGER,
    "occupantsDetails" TEXT,

    CONSTRAINT "CommercialProperty_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ShortletProperty" (
    "id" TEXT NOT NULL,
    "lotSize" INTEGER,
    "garageSpaces" INTEGER,
    "outdoorsSpacesFeatures" TEXT[],
    "buildingName" TEXT,
    "unitNumber" INTEGER,
    "buildingAmenityFeatures" TEXT[],
    "safetyFeatures" TEXT[],
    "customSafetyFeatures" TEXT[],
    "bedrooms" INTEGER,
    "beds" INTEGER,
    "bathrooms" INTEGER,
    "maxGuests" INTEGER,
    "propertySize" TEXT,
    "sizeUnit" "AreaUnit",
    "floorLevel" INTEGER,
    "totalFloors" INTEGER,
    "renovationYear" TEXT,
    "yearBuilt" INTEGER,
    "furnished" BOOLEAN NOT NULL DEFAULT true,
    "minStayDays" INTEGER,
    "maxStayDays" INTEGER,
    "availableFrom" TIMESTAMP(3),
    "availableTo" TIMESTAMP(3),
    "basePrice" DOUBLE PRECISION,
    "cleaningFee" DOUBLE PRECISION,
    "weeklyDiscount" DOUBLE PRECISION,
    "monthlyDiscount" DOUBLE PRECISION,
    "checkInTime" TEXT,
    "checkOutTime" TEXT,
    "instantBooking" BOOLEAN NOT NULL DEFAULT false,
    "allowChildren" BOOLEAN NOT NULL DEFAULT true,
    "allowInfants" BOOLEAN NOT NULL DEFAULT true,
    "allowPets" BOOLEAN NOT NULL DEFAULT false,
    "allowSmoking" BOOLEAN NOT NULL DEFAULT false,
    "allowParties" BOOLEAN NOT NULL DEFAULT false,
    "quietHours" BOOLEAN NOT NULL DEFAULT false,
    "quietHoursStart" TEXT,
    "quietHoursEnd" TEXT,
    "cancellationPolicy" "CancellationPolicy",
    "customCancellationPolicy" TEXT,
    "houseManual" TEXT,
    "checkInInstructions" TEXT,
    "localRecommendations" TEXT,
    "emergencyContact" TEXT,
    "hostName" TEXT,
    "hostPhotoUrl" TEXT,
    "responseRate" DOUBLE PRECISION,
    "responseTime" TEXT,
    "isSuperhost" BOOLEAN NOT NULL DEFAULT false,
    "joinedDate" TIMESTAMP(3),
    "otherSharedFacilities" TEXT[],
    "houseRule" TEXT,
    "maxOccupant" INTEGER,
    "isHMO" BOOLEAN,
    "isShareHouse" BOOLEAN,
    "isHMOLicenced" BOOLEAN,
    "hmoLicenceNumber" TEXT,
    "hmoLicenceExpiryDate" TIMESTAMP(3),
    "totalOccupants" INTEGER,
    "occupantsDetails" TEXT,

    CONSTRAINT "ShortletProperty_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommercialPropertyFloor" (
    "id" TEXT NOT NULL,
    "floorNumber" INTEGER NOT NULL,
    "area" TEXT,
    "price" TEXT NOT NULL,
    "available" BOOLEAN NOT NULL DEFAULT true,
    "partialFloor" BOOLEAN NOT NULL DEFAULT false,
    "description" TEXT,
    "amenities" TEXT[],
    "propertyId" TEXT NOT NULL,

    CONSTRAINT "CommercialPropertyFloor_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SeasonalPricing" (
    "id" TEXT NOT NULL,
    "seasonName" TEXT NOT NULL,
    "startDate" TIMESTAMP(3) NOT NULL,
    "endDate" TIMESTAMP(3) NOT NULL,
    "price" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,

    CONSTRAINT "SeasonalPricing_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Booking" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "checkInDate" TIMESTAMP(3) NOT NULL,
    "checkOutDate" TIMESTAMP(3) NOT NULL,
    "guestCount" INTEGER NOT NULL,
    "totalPrice" TEXT NOT NULL,
    "status" "BookingStatus" NOT NULL DEFAULT 'PENDING',
    "guestName" TEXT NOT NULL,
    "guestEmail" TEXT NOT NULL,
    "guestPhone" TEXT,
    "specialRequests" TEXT,
    "paymentStatus" TEXT,
    "paymentMethod" TEXT,
    "transactionReference" TEXT,
    "propertyId" TEXT NOT NULL,
    "userId" TEXT,
    "unitConfigurationId" TEXT,
    "roomDetailId" TEXT,
    "cancellationPolicy" "CancellationPolicy" DEFAULT 'FLEXIBLE',
    "isRefundable" "Refundability" NOT NULL DEFAULT 'YES',

    CONSTRAINT "Booking_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "propertySettings" (
    "id" TEXT NOT NULL,
    "landlordId" TEXT,
    "propertyId" TEXT,
    "settingType" "PropsSettingType" NOT NULL DEFAULT 'NOT_DEFINED',
    "lateFee" DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    "lateFeeFrequency" "LatePaymentFeeType",
    "lateFeePercentage" INTEGER DEFAULT 0,
    "gracePeriodDays" INTEGER,
    "depositPercentage" DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    "refundTimeframe" TEXT,
    "applicationFee" DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    "refundPolicy" "Refundability",
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "propertySettings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "taskManagement" (
    "id" TEXT NOT NULL,
    "taskName" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "dueDate" TIMESTAMP(3) NOT NULL,
    "completed" BOOLEAN NOT NULL DEFAULT false,
    "status" "StatusType" NOT NULL DEFAULT 'PENDING',
    "priority" "PriorityType" NOT NULL DEFAULT 'LOW',
    "propertyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "taskManagement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inventoryManageMent" (
    "id" TEXT NOT NULL,
    "itemName" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "status" "InventoryType" NOT NULL DEFAULT 'UNAVIALABLE',
    "itemLocation" TEXT NOT NULL,
    "propertyId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "inventoryManageMent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ExternalLandlord" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "name" TEXT NOT NULL,
    "contactNumber" TEXT NOT NULL,
    "emailAddress" TEXT NOT NULL,

    CONSTRAINT "ExternalLandlord_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LandlordReferenceForm" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "status" "ReferenceStatus" NOT NULL DEFAULT 'PENDING',
    "TenancyReferenceHistoryId" TEXT NOT NULL,
    "externalLandlordId" TEXT NOT NULL,
    "conductId" TEXT NOT NULL,
    "additionalComments" TEXT,
    "signerName" TEXT,
    "signature" TEXT,
    "signedDate" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "applicationId" TEXT NOT NULL,

    CONSTRAINT "LandlordReferenceForm_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TenancyReferenceHistory" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "tenantName" TEXT NOT NULL,
    "currentAddress" TEXT NOT NULL,
    "monthlyRent" TEXT,
    "rentStartDate" TIMESTAMP(3),
    "rentEndDate" TIMESTAMP(3),
    "reasonForLeaving" TEXT,

    CONSTRAINT "TenancyReferenceHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TenantConduct" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "rentOnTime" BOOLEAN,
    "rentOnTimeDetails" TEXT,
    "rentArrears" BOOLEAN,
    "rentArrearsDetails" TEXT,
    "propertyCondition" BOOLEAN,
    "propertyConditionDetails" TEXT,
    "complaints" BOOLEAN,
    "complaintsDetails" TEXT,
    "endCondition" BOOLEAN,
    "endConditionDetails" TEXT,
    "rentAgain" BOOLEAN,
    "rentAgainDetails" TEXT,

    CONSTRAINT "TenantConduct_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GuarantorAgreement" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'DRAFT',
    "submittedAt" TIMESTAMP(3),
    "title" TEXT,
    "firstName" TEXT NOT NULL,
    "middleName" TEXT,
    "lastName" TEXT NOT NULL,
    "dateOfBirth" TIMESTAMP(3) NOT NULL,
    "nationalInsuranceNumber" TEXT,
    "contactNumber" TEXT NOT NULL,
    "emailAddress" TEXT NOT NULL,
    "guarantorId" TEXT NOT NULL,
    "guarantorEmployment" JSONB,
    "signedByGuarantor" BOOLEAN NOT NULL DEFAULT false,
    "guarantorSignature" TEXT,
    "guarantorSignedAt" TIMESTAMP(3),
    "applicationId" TEXT NOT NULL,

    CONSTRAINT "GuarantorAgreement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "EmployeeReferenceForm" (
    "id" TEXT NOT NULL,
    "employeeName" TEXT,
    "jobTitle" TEXT,
    "department" TEXT,
    "employmentStartDate" TIMESTAMP(3),
    "employmentEndDate" TIMESTAMP(3),
    "reasonForLeaving" TEXT,
    "companyName" TEXT,
    "refereeName" TEXT,
    "refereePosition" TEXT,
    "contactNumber" TEXT,
    "emailAddress" TEXT,
    "employmentType" TEXT,
    "mainResponsibilities" TEXT,
    "workPerformance" INTEGER,
    "punctualityAttendance" INTEGER,
    "reliabilityProfessionalism" INTEGER,
    "teamworkInterpersonal" INTEGER,
    "wouldReemploy" BOOLEAN,
    "reemployDetails" TEXT,
    "additionalComments" TEXT,
    "declarationConfirmed" BOOLEAN NOT NULL DEFAULT true,
    "signerName" TEXT,
    "signature" TEXT,
    "date" TIMESTAMP(3),
    "applicationId" TEXT NOT NULL,

    CONSTRAINT "EmployeeReferenceForm_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "reviews" (
    "id" TEXT NOT NULL,
    "rating" DOUBLE PRECISION NOT NULL,
    "type" "ReviewType" DEFAULT 'NORMAL_REVIEW',
    "comment" TEXT,
    "tenantId" TEXT,
    "vendorId" TEXT,
    "landlordId" TEXT,
    "propertyId" TEXT,
    "reviewById" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "reviews_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Ads" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "amountPaid" DECIMAL(18,2) NOT NULL,
    "locations" TEXT[],
    "bussinessDetails" JSONB NOT NULL,
    "contactInfo" TEXT NOT NULL,
    "startedDate" TIMESTAMP(3) NOT NULL,
    "endDate" TIMESTAMP(3) NOT NULL,
    "attachment" TEXT[],
    "isListed" BOOLEAN NOT NULL DEFAULT false,
    "views" INTEGER NOT NULL DEFAULT 0,
    "clicks" INTEGER NOT NULL DEFAULT 0,
    "reach" INTEGER NOT NULL DEFAULT 0,
    "userId" TEXT NOT NULL,
    "referenceId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Ads_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "landlords" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "landlordCode" TEXT,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "stripeCustomerId" TEXT,
    "emailDomains" TEXT,

    CONSTRAINT "landlords_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "bankInfo" (
    "id" TEXT NOT NULL,
    "landlordId" TEXT,
    "vendorId" TEXT,
    "bankName" TEXT NOT NULL,
    "accountNumber" TEXT NOT NULL,
    "accountName" TEXT NOT NULL,

    CONSTRAINT "bankInfo_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agency" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,

    CONSTRAINT "agency_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "agents" (
    "id" TEXT NOT NULL,
    "agentId" TEXT,
    "about" TEXT,
    "facebook" TEXT,
    "twitter" TEXT,
    "instagram" TEXT,
    "linkedin" TEXT,
    "createdAt" TIMESTAMPTZ(6) DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(6) DEFAULT CURRENT_TIMESTAMP,
    "userId" TEXT NOT NULL,
    "agencyId" TEXT,
    "propertyId" TEXT,

    CONSTRAINT "agents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Rating" (
    "id" TEXT NOT NULL,
    "ratingValue" INTEGER NOT NULL DEFAULT 0,
    "comments" TEXT,
    "propertyId" TEXT,
    "userId" TEXT,
    "ratedByUserId" TEXT NOT NULL,
    "createdAt" TIMESTAMPTZ(6) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMPTZ(6) NOT NULL,

    CONSTRAINT "Rating_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "vendors" (
    "id" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "userId" TEXT,

    CONSTRAINT "vendors_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tenants" (
    "id" TEXT NOT NULL,
    "tenantId" TEXT,
    "landlordId" TEXT NOT NULL,
    "tenantCode" TEXT,
    "password" TEXT,
    "rentstatus" INTEGER,
    "leaseStartDate" TIMESTAMP(3),
    "leaseEndDate" TIMESTAMP(3),
    "isCurrentLease" BOOLEAN NOT NULL DEFAULT true,
    "initialDeposit" DECIMAL(18,2) DEFAULT 0.00,
    "dateOfFirstRent" TIMESTAMPTZ(6) DEFAULT CURRENT_TIMESTAMP,
    "apartmentOrFlatNumber" INTEGER,
    "stripeCustomerId" TEXT,
    "tenantWebUserEmail" TEXT,
    "userId" TEXT NOT NULL,
    "agentId" TEXT,
    "propertyId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "applicationId" TEXT,

    CONSTRAINT "tenants_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "creditScore" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "score" INTEGER NOT NULL,
    "lastUpdated" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "paymentHistory" DOUBLE PRECISION NOT NULL,
    "rentalHistory" DOUBLE PRECISION NOT NULL,
    "maintainanceScore" DOUBLE PRECISION NOT NULL,
    "reviewScore" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "creditScore_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "VerificationToken" (
    "id" SERIAL NOT NULL,
    "token" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "VerificationToken_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "status" (
    "id" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "status_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Settings" (
    "id" TEXT NOT NULL,
    "percentageOrAmount" INTEGER,
    "type" "SettingType" NOT NULL DEFAULT 'SECURITY_DEPOSIT',
    "landlordId" TEXT,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Settings_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "state" (
    "id" TEXT NOT NULL,
    "name" TEXT,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "state_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "landlordSupportTicket" (
    "id" TEXT NOT NULL,
    "landlordId" TEXT NOT NULL,
    "supportTicketNumber" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "status" "TicketStatus" NOT NULL DEFAULT 'OPEN',
    "attachment" TEXT[],
    "assignedTo" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "landlordSupportTicket_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tenantSupportTicket" (
    "id" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "supportTicketNumber" TEXT NOT NULL,
    "subject" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "status" "TicketStatus" NOT NULL DEFAULT 'OPEN',
    "attachment" TEXT[],
    "assignedTo" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "tenantSupportTicket_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Transaction" (
    "id" TEXT NOT NULL,
    "description" TEXT,
    "amount" DECIMAL(18,2) NOT NULL,
    "userId" TEXT NOT NULL,
    "walletId" TEXT,
    "type" "TransactionType" NOT NULL,
    "reference" "TransactionReference" NOT NULL,
    "status" "TransactionStatus" NOT NULL,
    "referenceId" TEXT NOT NULL,
    "paymentGateway" "PaymentGateway",
    "stripePaymentIntentId" TEXT,
    "propertyId" TEXT,
    "billId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "currency" TEXT,
    "isDue" BOOLEAN DEFAULT false,
    "securityDepositPercentage" INTEGER,

    CONSTRAINT "Transaction_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "tenantPaymentHistory" (
    "id" TEXT NOT NULL,
    "rentStartDate" TIMESTAMPTZ(6),
    "rentEndDate" TIMESTAMPTZ(6),
    "expectedRentAmount" DECIMAL(18,2),
    "amountPaid" DECIMAL(18,2),
    "tenantId" TEXT,

    CONSTRAINT "tenantPaymentHistory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "bills" (
    "id" TEXT NOT NULL,
    "billId" TEXT NOT NULL,
    "billName" TEXT NOT NULL,
    "billCategory" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "amount" DECIMAL(18,2) NOT NULL,
    "billFrequency" "PaymentFrequency" NOT NULL,
    "dueDate" TIMESTAMP(3) NOT NULL,
    "payableBy" "PayableBy" DEFAULT 'LANDLORD',
    "propertyId" TEXT,
    "landlordId" TEXT,
    "tenantId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "bills_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Subscription" (
    "id" TEXT NOT NULL,
    "stripeSubscriptionId" TEXT NOT NULL,
    "status" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "cancelledAt" TIMESTAMP(3),

    CONSTRAINT "Subscription_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Budget" (
    "id" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "transactionType" "TransactionReference" NOT NULL,
    "budgetAmount" DOUBLE PRECISION NOT NULL,
    "currentAmount" DOUBLE PRECISION NOT NULL DEFAULT 0,
    "frequency" "BudgetFrequency" NOT NULL,
    "alertThreshold" DOUBLE PRECISION NOT NULL DEFAULT 0.8,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Budget_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "password" TEXT,
    "isVerified" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "role" "userRoles"[] DEFAULT ARRAY['WEBUSER']::"userRoles"[],
    "onlineStatus" "onlineStatus" DEFAULT 'offline',
    "profileId" TEXT,
    "stripeCustomerId" TEXT,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserLikedProperty" (
    "id" TEXT NOT NULL,
    "userId" TEXT,
    "propertyId" TEXT,
    "likedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "UserLikedProperty_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserSearchPreference" (
    "id" TEXT NOT NULL,
    "description" TEXT,
    "userId" TEXT NOT NULL,
    "types" "PropertyType"[],
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "UserSearchPreference_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "violation" (
    "id" TEXT NOT NULL,
    "actionTaken" TEXT,
    "noticeType" "NoticeType",
    "deliveryMethod" "DeliveryMethod",
    "description" TEXT NOT NULL,
    "severityLevel" "SeverityLevel" DEFAULT 'LOW',
    "propertyId" TEXT,
    "tenantId" TEXT,
    "createdById" TEXT,
    "unitId" TEXT,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,
    "dueDate" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "violation_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TenantLeaseBreach" (
    "id" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "breachType" "LeaseBreachType" NOT NULL,
    "description" TEXT NOT NULL,
    "date" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "resolved" BOOLEAN NOT NULL DEFAULT false,
    "repeatOffense" BOOLEAN NOT NULL DEFAULT false,
    "resolutionDate" TIMESTAMP(3),
    "penaltyAmount" DECIMAL(10,2),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TenantLeaseBreach_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "wallet" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "balance" DECIMAL(18,2) NOT NULL DEFAULT 0.00,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "currency" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "wallet_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_applicationTousers" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "_RoomImages" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "_UnitImages" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "_SubCategoryMaintenance" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "_ResidentialPropertyTobills" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "application_applicationInviteId_key" ON "application"("applicationInviteId");

-- CreateIndex
CREATE UNIQUE INDEX "applicantPersonalDetails_email_key" ON "applicantPersonalDetails"("email");

-- CreateIndex
CREATE UNIQUE INDEX "nextOfKin_applicantPersonalDetailsId_key" ON "nextOfKin"("applicantPersonalDetailsId");

-- CreateIndex
CREATE UNIQUE INDEX "ChatRoom_maintenanceId_key" ON "ChatRoom"("maintenanceId");

-- CreateIndex
CREATE UNIQUE INDEX "ChatRoom_user1Id_user2Id_key" ON "ChatRoom"("user1Id", "user2Id");

-- CreateIndex
CREATE UNIQUE INDEX "Community_communityName_key" ON "Community"("communityName");

-- CreateIndex
CREATE UNIQUE INDEX "CommunityMember_communityId_userId_key" ON "CommunityMember"("communityId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "CommunityInvitationLink_inviteCode_key" ON "CommunityInvitationLink"("inviteCode");

-- CreateIndex
CREATE INDEX "CommunityInvitationLink_inviteCode_idx" ON "CommunityInvitationLink"("inviteCode");

-- CreateIndex
CREATE INDEX "Comments_parentCommentId_idx" ON "Comments"("parentCommentId");

-- CreateIndex
CREATE INDEX "PropertyMediaFiles_image_property_id_idx" ON "PropertyMediaFiles"("image_property_id");

-- CreateIndex
CREATE INDEX "PropertyMediaFiles_video_property_id_idx" ON "PropertyMediaFiles"("video_property_id");

-- CreateIndex
CREATE INDEX "PropertyMediaFiles_virtual_tour_property_id_idx" ON "PropertyMediaFiles"("virtual_tour_property_id");

-- CreateIndex
CREATE UNIQUE INDEX "maintenance_chatRoomId_key" ON "maintenance"("chatRoomId");

-- CreateIndex
CREATE UNIQUE INDEX "propertyListingHistory_propertyId_key" ON "propertyListingHistory"("propertyId");

-- CreateIndex
CREATE UNIQUE INDEX "properties_landlordId_name_stateId_city_key" ON "properties"("landlordId", "name", "stateId", "city");

-- CreateIndex
CREATE UNIQUE INDEX "SharedFacilities_residentialPropertyId_key" ON "SharedFacilities"("residentialPropertyId");

-- CreateIndex
CREATE UNIQUE INDEX "propertySettings_propertyId_settingType_key" ON "propertySettings"("propertyId", "settingType");

-- CreateIndex
CREATE UNIQUE INDEX "LandlordReferenceForm_TenancyReferenceHistoryId_key" ON "LandlordReferenceForm"("TenancyReferenceHistoryId");

-- CreateIndex
CREATE UNIQUE INDEX "LandlordReferenceForm_externalLandlordId_key" ON "LandlordReferenceForm"("externalLandlordId");

-- CreateIndex
CREATE UNIQUE INDEX "LandlordReferenceForm_conductId_key" ON "LandlordReferenceForm"("conductId");

-- CreateIndex
CREATE UNIQUE INDEX "LandlordReferenceForm_applicationId_key" ON "LandlordReferenceForm"("applicationId");

-- CreateIndex
CREATE UNIQUE INDEX "GuarantorAgreement_guarantorId_key" ON "GuarantorAgreement"("guarantorId");

-- CreateIndex
CREATE UNIQUE INDEX "GuarantorAgreement_applicationId_key" ON "GuarantorAgreement"("applicationId");

-- CreateIndex
CREATE UNIQUE INDEX "EmployeeReferenceForm_applicationId_key" ON "EmployeeReferenceForm"("applicationId");

-- CreateIndex
CREATE UNIQUE INDEX "landlords_userId_key" ON "landlords"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "landlords_landlordCode_key" ON "landlords"("landlordCode");

-- CreateIndex
CREATE UNIQUE INDEX "landlords_stripeCustomerId_key" ON "landlords"("stripeCustomerId");

-- CreateIndex
CREATE UNIQUE INDEX "landlords_emailDomains_key" ON "landlords"("emailDomains");

-- CreateIndex
CREATE UNIQUE INDEX "vendors_userId_key" ON "vendors"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "tenants_tenantId_key" ON "tenants"("tenantId");

-- CreateIndex
CREATE UNIQUE INDEX "tenants_tenantCode_key" ON "tenants"("tenantCode");

-- CreateIndex
CREATE UNIQUE INDEX "tenants_stripeCustomerId_key" ON "tenants"("stripeCustomerId");

-- CreateIndex
CREATE UNIQUE INDEX "tenants_applicationId_key" ON "tenants"("applicationId");

-- CreateIndex
CREATE UNIQUE INDEX "tenants_userId_propertyId_key" ON "tenants"("userId", "propertyId");

-- CreateIndex
CREATE UNIQUE INDEX "tenants_userId_key" ON "tenants"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "creditScore_userId_key" ON "creditScore"("userId");

-- CreateIndex
CREATE UNIQUE INDEX "VerificationToken_token_key" ON "VerificationToken"("token");

-- CreateIndex
CREATE UNIQUE INDEX "Transaction_stripePaymentIntentId_key" ON "Transaction"("stripePaymentIntentId");

-- CreateIndex
CREATE UNIQUE INDEX "bills_billId_key" ON "bills"("billId");

-- CreateIndex
CREATE UNIQUE INDEX "Subscription_stripeSubscriptionId_key" ON "Subscription"("stripeSubscriptionId");

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "users_profileId_key" ON "users"("profileId");

-- CreateIndex
CREATE UNIQUE INDEX "users_stripeCustomerId_key" ON "users"("stripeCustomerId");

-- CreateIndex
CREATE UNIQUE INDEX "UserLikedProperty_userId_propertyId_key" ON "UserLikedProperty"("userId", "propertyId");

-- CreateIndex
CREATE UNIQUE INDEX "UserSearchPreference_description_key" ON "UserSearchPreference"("description");

-- CreateIndex
CREATE UNIQUE INDEX "UserSearchPreference_userId_key" ON "UserSearchPreference"("userId");

-- CreateIndex
CREATE INDEX "TenantLeaseBreach_tenantId_propertyId_idx" ON "TenantLeaseBreach"("tenantId", "propertyId");

-- CreateIndex
CREATE UNIQUE INDEX "wallet_userId_currency_key" ON "wallet"("userId", "currency");

-- CreateIndex
CREATE UNIQUE INDEX "_applicationTousers_AB_unique" ON "_applicationTousers"("A", "B");

-- CreateIndex
CREATE INDEX "_applicationTousers_B_index" ON "_applicationTousers"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_RoomImages_AB_unique" ON "_RoomImages"("A", "B");

-- CreateIndex
CREATE INDEX "_RoomImages_B_index" ON "_RoomImages"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_UnitImages_AB_unique" ON "_UnitImages"("A", "B");

-- CreateIndex
CREATE INDEX "_UnitImages_B_index" ON "_UnitImages"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_SubCategoryMaintenance_AB_unique" ON "_SubCategoryMaintenance"("A", "B");

-- CreateIndex
CREATE INDEX "_SubCategoryMaintenance_B_index" ON "_SubCategoryMaintenance"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_ResidentialPropertyTobills_AB_unique" ON "_ResidentialPropertyTobills"("A", "B");

-- CreateIndex
CREATE INDEX "_ResidentialPropertyTobills_B_index" ON "_ResidentialPropertyTobills"("B");

-- AddForeignKey
ALTER TABLE "applicationInvites" ADD CONSTRAINT "applicationInvites_propertiesId_fkey" FOREIGN KEY ("propertiesId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "applicationInvites" ADD CONSTRAINT "applicationInvites_invitedByLandordId_fkey" FOREIGN KEY ("invitedByLandordId") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "applicationInvites" ADD CONSTRAINT "applicationInvites_tenantsId_fkey" FOREIGN KEY ("tenantsId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "applicationInvites" ADD CONSTRAINT "applicationInvites_userInvitedId_fkey" FOREIGN KEY ("userInvitedId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "applicationInvites" ADD CONSTRAINT "applicationInvites_enquiryId_fkey" FOREIGN KEY ("enquiryId") REFERENCES "Log"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_residentialId_fkey" FOREIGN KEY ("residentialId") REFERENCES "residentialInformation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_emergencyContactId_fkey" FOREIGN KEY ("emergencyContactId") REFERENCES "emergencyContact"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_employmentInformationId_fkey" FOREIGN KEY ("employmentInformationId") REFERENCES "EmploymentInformation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_propertiesId_fkey" FOREIGN KEY ("propertiesId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_applicantPersonalDetailsId_fkey" FOREIGN KEY ("applicantPersonalDetailsId") REFERENCES "applicantPersonalDetails"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_guarantorInformationId_fkey" FOREIGN KEY ("guarantorInformationId") REFERENCES "guarantorInformation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_refereeId_fkey" FOREIGN KEY ("refereeId") REFERENCES "referees"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_updatedById_fkey" FOREIGN KEY ("updatedById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "application" ADD CONSTRAINT "application_applicationInviteId_fkey" FOREIGN KEY ("applicationInviteId") REFERENCES "applicationInvites"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "applicantPersonalDetails" ADD CONSTRAINT "applicantPersonalDetails_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "nextOfKin" ADD CONSTRAINT "nextOfKin_applicantPersonalDetailsId_fkey" FOREIGN KEY ("applicantPersonalDetailsId") REFERENCES "applicantPersonalDetails"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "nextOfKin" ADD CONSTRAINT "nextOfKin_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PrevAddress" ADD CONSTRAINT "PrevAddress_residentialInformationId_fkey" FOREIGN KEY ("residentialInformationId") REFERENCES "residentialInformation"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "residentialInformation" ADD CONSTRAINT "residentialInformation_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "guarantorInformation" ADD CONSTRAINT "guarantorInformation_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "emergencyContact" ADD CONSTRAINT "emergencyContact_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "referees" ADD CONSTRAINT "referees_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmploymentInformation" ADD CONSTRAINT "EmploymentInformation_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "applicationQuestions" ADD CONSTRAINT "applicationQuestions_applicantId_fkey" FOREIGN KEY ("applicantId") REFERENCES "application"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "declaration" ADD CONSTRAINT "declaration_applicantId_fkey" FOREIGN KEY ("applicantId") REFERENCES "application"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Broadcast" ADD CONSTRAINT "Broadcast_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "subCategory" ADD CONSTRAINT "subCategory_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "category"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Message" ADD CONSTRAINT "Message_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Message" ADD CONSTRAINT "Message_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Message" ADD CONSTRAINT "Message_chatRoomId_fkey" FOREIGN KEY ("chatRoomId") REFERENCES "ChatRoom"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ChatRoom" ADD CONSTRAINT "ChatRoom_user1Id_fkey" FOREIGN KEY ("user1Id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ChatRoom" ADD CONSTRAINT "ChatRoom_user2Id_fkey" FOREIGN KEY ("user2Id") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Community" ADD CONSTRAINT "Community_communityOwnerId_fkey" FOREIGN KEY ("communityOwnerId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityMember" ADD CONSTRAINT "CommunityMember_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "Community"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityMember" ADD CONSTRAINT "CommunityMember_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityInvitationLink" ADD CONSTRAINT "CommunityInvitationLink_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "Community"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPost" ADD CONSTRAINT "CommunityPost_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostLikes" ADD CONSTRAINT "CommunityPostLikes_postId_fkey" FOREIGN KEY ("postId") REFERENCES "CommunityPost"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostLikes" ADD CONSTRAINT "CommunityPostLikes_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostViews" ADD CONSTRAINT "CommunityPostViews_postId_fkey" FOREIGN KEY ("postId") REFERENCES "CommunityPost"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostViews" ADD CONSTRAINT "CommunityPostViews_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Comments" ADD CONSTRAINT "Comments_postId_fkey" FOREIGN KEY ("postId") REFERENCES "CommunityPost"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Comments" ADD CONSTRAINT "Comments_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Comments" ADD CONSTRAINT "Comments_parentCommentId_fkey" FOREIGN KEY ("parentCommentId") REFERENCES "Comments"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Complaint" ADD CONSTRAINT "Complaint_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Complaint" ADD CONSTRAINT "Complaint_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertyDocument" ADD CONSTRAINT "propertyDocument_agreementId_fkey" FOREIGN KEY ("agreementId") REFERENCES "GuarantorAgreement"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertyDocument" ADD CONSTRAINT "propertyDocument_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES "application"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertyDocument" ADD CONSTRAINT "propertyDocument_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertyDocument" ADD CONSTRAINT "propertyDocument_uploadedBy_fkey" FOREIGN KEY ("uploadedBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PropertyMediaFiles" ADD CONSTRAINT "PropertyMediaFiles_image_property_id_fkey" FOREIGN KEY ("image_property_id") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PropertyMediaFiles" ADD CONSTRAINT "PropertyMediaFiles_video_property_id_fkey" FOREIGN KEY ("video_property_id") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PropertyMediaFiles" ADD CONSTRAINT "PropertyMediaFiles_virtual_tour_property_id_fkey" FOREIGN KEY ("virtual_tour_property_id") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Email" ADD CONSTRAINT "Email_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Email" ADD CONSTRAINT "Email_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection" ADD CONSTRAINT "inspection_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection" ADD CONSTRAINT "inspection_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Log" ADD CONSTRAINT "Log_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Log" ADD CONSTRAINT "Log_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES "application"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Log" ADD CONSTRAINT "Log_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES "Transaction"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Log" ADD CONSTRAINT "Log_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "category"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_chatRoomId_fkey" FOREIGN KEY ("chatRoomId") REFERENCES "ChatRoom"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenance" ADD CONSTRAINT "maintenance_serviceId_fkey" FOREIGN KEY ("serviceId") REFERENCES "services"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenanceRescheduleHistory" ADD CONSTRAINT "maintenanceRescheduleHistory_maintenanceId_fkey" FOREIGN KEY ("maintenanceId") REFERENCES "maintenance"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "services" ADD CONSTRAINT "services_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "services" ADD CONSTRAINT "services_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "category"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "services" ADD CONSTRAINT "services_subcategoryId_fkey" FOREIGN KEY ("subcategoryId") REFERENCES "subCategory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "services" ADD CONSTRAINT "services_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenanceWhitelist" ADD CONSTRAINT "maintenanceWhitelist_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "category"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenanceWhitelist" ADD CONSTRAINT "maintenanceWhitelist_subcategoryId_fkey" FOREIGN KEY ("subcategoryId") REFERENCES "subCategory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenanceWhitelist" ADD CONSTRAINT "maintenanceWhitelist_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenanceWhitelist" ADD CONSTRAINT "maintenanceWhitelist_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertyListingHistory" ADD CONSTRAINT "propertyListingHistory_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertyListingHistory" ADD CONSTRAINT "propertyListingHistory_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "UnitConfiguration"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertyListingHistory" ADD CONSTRAINT "propertyListingHistory_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "RoomDetail"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SuitableUse" ADD CONSTRAINT "SuitableUse_commercialPropertyId_fkey" FOREIGN KEY ("commercialPropertyId") REFERENCES "CommercialProperty"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AdditionalRule" ADD CONSTRAINT "AdditionalRule_shortletId_fkey" FOREIGN KEY ("shortletId") REFERENCES "ShortletProperty"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UnavailableDate" ADD CONSTRAINT "UnavailableDate_shortletId_fkey" FOREIGN KEY ("shortletId") REFERENCES "ShortletProperty"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HostLanguage" ADD CONSTRAINT "HostLanguage_shortletId_fkey" FOREIGN KEY ("shortletId") REFERENCES "ShortletProperty"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "properties" ADD CONSTRAINT "properties_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "properties" ADD CONSTRAINT "properties_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES "agency"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "properties" ADD CONSTRAINT "properties_stateId_fkey" FOREIGN KEY ("stateId") REFERENCES "state"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PropertySpecification" ADD CONSTRAINT "PropertySpecification_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PropertySpecification" ADD CONSTRAINT "PropertySpecification_residentialId_fkey" FOREIGN KEY ("residentialId") REFERENCES "ResidentialProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PropertySpecification" ADD CONSTRAINT "PropertySpecification_commercialId_fkey" FOREIGN KEY ("commercialId") REFERENCES "CommercialProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PropertySpecification" ADD CONSTRAINT "PropertySpecification_shortletId_fkey" FOREIGN KEY ("shortletId") REFERENCES "ShortletProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SharedFacilities" ADD CONSTRAINT "SharedFacilities_residentialPropertyId_fkey" FOREIGN KEY ("residentialPropertyId") REFERENCES "ResidentialProperty"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SharedFacilities" ADD CONSTRAINT "SharedFacilities_commercialPropertyId_fkey" FOREIGN KEY ("commercialPropertyId") REFERENCES "CommercialProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SharedFacilities" ADD CONSTRAINT "SharedFacilities_shortletPropertyId_fkey" FOREIGN KEY ("shortletPropertyId") REFERENCES "ShortletProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UnitConfiguration" ADD CONSTRAINT "UnitConfiguration_residentialPropertyId_fkey" FOREIGN KEY ("residentialPropertyId") REFERENCES "ResidentialProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UnitConfiguration" ADD CONSTRAINT "UnitConfiguration_commercialPropertyId_fkey" FOREIGN KEY ("commercialPropertyId") REFERENCES "CommercialProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RoomDetail" ADD CONSTRAINT "RoomDetail_residentialPropertyId_fkey" FOREIGN KEY ("residentialPropertyId") REFERENCES "ResidentialProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RoomDetail" ADD CONSTRAINT "RoomDetail_commercialPropertyId_fkey" FOREIGN KEY ("commercialPropertyId") REFERENCES "CommercialProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RoomDetail" ADD CONSTRAINT "RoomDetail_shortletPropertyId_fkey" FOREIGN KEY ("shortletPropertyId") REFERENCES "ShortletProperty"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommercialPropertyFloor" ADD CONSTRAINT "CommercialPropertyFloor_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "CommercialProperty"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SeasonalPricing" ADD CONSTRAINT "SeasonalPricing_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "ShortletProperty"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Booking" ADD CONSTRAINT "Booking_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "ShortletProperty"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Booking" ADD CONSTRAINT "Booking_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Booking" ADD CONSTRAINT "Booking_unitConfigurationId_fkey" FOREIGN KEY ("unitConfigurationId") REFERENCES "UnitConfiguration"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Booking" ADD CONSTRAINT "Booking_roomDetailId_fkey" FOREIGN KEY ("roomDetailId") REFERENCES "RoomDetail"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertySettings" ADD CONSTRAINT "propertySettings_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "propertySettings" ADD CONSTRAINT "propertySettings_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "taskManagement" ADD CONSTRAINT "taskManagement_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inventoryManageMent" ADD CONSTRAINT "inventoryManageMent_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LandlordReferenceForm" ADD CONSTRAINT "LandlordReferenceForm_TenancyReferenceHistoryId_fkey" FOREIGN KEY ("TenancyReferenceHistoryId") REFERENCES "TenancyReferenceHistory"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LandlordReferenceForm" ADD CONSTRAINT "LandlordReferenceForm_externalLandlordId_fkey" FOREIGN KEY ("externalLandlordId") REFERENCES "ExternalLandlord"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LandlordReferenceForm" ADD CONSTRAINT "LandlordReferenceForm_conductId_fkey" FOREIGN KEY ("conductId") REFERENCES "TenantConduct"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LandlordReferenceForm" ADD CONSTRAINT "LandlordReferenceForm_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES "application"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GuarantorAgreement" ADD CONSTRAINT "GuarantorAgreement_guarantorId_fkey" FOREIGN KEY ("guarantorId") REFERENCES "guarantorInformation"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GuarantorAgreement" ADD CONSTRAINT "GuarantorAgreement_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES "application"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "EmployeeReferenceForm" ADD CONSTRAINT "EmployeeReferenceForm_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES "application"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "reviews" ADD CONSTRAINT "reviews_reviewById_fkey" FOREIGN KEY ("reviewById") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Ads" ADD CONSTRAINT "Ads_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Ads" ADD CONSTRAINT "Ads_referenceId_fkey" FOREIGN KEY ("referenceId") REFERENCES "Transaction"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "landlords" ADD CONSTRAINT "landlords_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bankInfo" ADD CONSTRAINT "bankInfo_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bankInfo" ADD CONSTRAINT "bankInfo_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agents" ADD CONSTRAINT "agents_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agents" ADD CONSTRAINT "agents_agencyId_fkey" FOREIGN KEY ("agencyId") REFERENCES "agency"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "agents" ADD CONSTRAINT "agents_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Rating" ADD CONSTRAINT "Rating_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Rating" ADD CONSTRAINT "Rating_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Rating" ADD CONSTRAINT "Rating_ratedByUserId_fkey" FOREIGN KEY ("ratedByUserId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "vendors" ADD CONSTRAINT "vendors_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenants" ADD CONSTRAINT "tenants_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenants" ADD CONSTRAINT "tenants_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenants" ADD CONSTRAINT "tenants_agentId_fkey" FOREIGN KEY ("agentId") REFERENCES "agents"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenants" ADD CONSTRAINT "tenants_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenants" ADD CONSTRAINT "tenants_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES "application"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "creditScore" ADD CONSTRAINT "creditScore_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VerificationToken" ADD CONSTRAINT "VerificationToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Settings" ADD CONSTRAINT "Settings_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "landlordSupportTicket" ADD CONSTRAINT "landlordSupportTicket_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenantSupportTicket" ADD CONSTRAINT "tenantSupportTicket_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Transaction" ADD CONSTRAINT "Transaction_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Transaction" ADD CONSTRAINT "Transaction_walletId_fkey" FOREIGN KEY ("walletId") REFERENCES "wallet"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Transaction" ADD CONSTRAINT "Transaction_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Transaction" ADD CONSTRAINT "Transaction_billId_fkey" FOREIGN KEY ("billId") REFERENCES "bills"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "tenantPaymentHistory" ADD CONSTRAINT "tenantPaymentHistory_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bills" ADD CONSTRAINT "bills_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bills" ADD CONSTRAINT "bills_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "bills" ADD CONSTRAINT "bills_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Subscription" ADD CONSTRAINT "Subscription_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Budget" ADD CONSTRAINT "Budget_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "users" ADD CONSTRAINT "users_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES "profile"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserLikedProperty" ADD CONSTRAINT "UserLikedProperty_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserLikedProperty" ADD CONSTRAINT "UserLikedProperty_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserSearchPreference" ADD CONSTRAINT "UserSearchPreference_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "violation" ADD CONSTRAINT "violation_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "violation" ADD CONSTRAINT "violation_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "violation" ADD CONSTRAINT "violation_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "UnitConfiguration"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "violation" ADD CONSTRAINT "violation_createdById_fkey" FOREIGN KEY ("createdById") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TenantLeaseBreach" ADD CONSTRAINT "TenantLeaseBreach_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TenantLeaseBreach" ADD CONSTRAINT "TenantLeaseBreach_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "wallet" ADD CONSTRAINT "wallet_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_applicationTousers" ADD CONSTRAINT "_applicationTousers_A_fkey" FOREIGN KEY ("A") REFERENCES "application"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_applicationTousers" ADD CONSTRAINT "_applicationTousers_B_fkey" FOREIGN KEY ("B") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_RoomImages" ADD CONSTRAINT "_RoomImages_A_fkey" FOREIGN KEY ("A") REFERENCES "PropertyMediaFiles"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_RoomImages" ADD CONSTRAINT "_RoomImages_B_fkey" FOREIGN KEY ("B") REFERENCES "RoomDetail"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_UnitImages" ADD CONSTRAINT "_UnitImages_A_fkey" FOREIGN KEY ("A") REFERENCES "PropertyMediaFiles"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_UnitImages" ADD CONSTRAINT "_UnitImages_B_fkey" FOREIGN KEY ("B") REFERENCES "UnitConfiguration"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_SubCategoryMaintenance" ADD CONSTRAINT "_SubCategoryMaintenance_A_fkey" FOREIGN KEY ("A") REFERENCES "maintenance"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_SubCategoryMaintenance" ADD CONSTRAINT "_SubCategoryMaintenance_B_fkey" FOREIGN KEY ("B") REFERENCES "subCategory"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_ResidentialPropertyTobills" ADD CONSTRAINT "_ResidentialPropertyTobills_A_fkey" FOREIGN KEY ("A") REFERENCES "ResidentialProperty"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_ResidentialPropertyTobills" ADD CONSTRAINT "_ResidentialPropertyTobills_B_fkey" FOREIGN KEY ("B") REFERENCES "bills"("id") ON DELETE CASCADE ON UPDATE CASCADE;
