-- AlterTable
ALTER TABLE "Log" ADD COLUMN     "propertyListingId" TEXT,
ADD COLUMN     "roomId" TEXT,
ADD COLUMN     "unitId" TEXT;

-- AlterTable
ALTER TABLE "applicationInvites" ADD COLUMN     "propertyListingId" TEXT;

-- AddForeignKey
ALTER TABLE "applicationInvites" ADD CONSTRAINT "applicationInvites_propertyListingId_fkey" FOREIGN KEY ("propertyListingId") REFERENCES "propertyListingHistory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Log" ADD CONSTRAINT "Log_propertyListingId_fkey" FOREIGN KEY ("propertyListingId") REFERENCES "propertyListingHistory"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Log" ADD CONSTRAINT "Log_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "UnitConfiguration"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Log" ADD CONSTRAINT "Log_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "RoomDetail"("id") ON DELETE SET NULL ON UPDATE CASCADE;
