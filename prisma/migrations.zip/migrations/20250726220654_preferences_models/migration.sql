-- CreateEnum
CREATE TYPE "TimeFormat" AS ENUM ('H12', 'H24');

-- CreateEnum
CREATE TYPE "DateFormat" AS ENUM ('MM_DD_YYYY', 'DD_MM_YYYY', 'YYYY_MM_DD');

-- CreateEnum
CREATE TYPE "Language" AS ENUM ('ENGLISH', 'SPANISH', 'FRENCH', 'GERMAN');

-- CreateTable
CREATE TABLE "UserPreferences" (
    "id" TEXT NOT NULL,
    "defaultPaymentAccountId" TEXT,
    "currency" "Currency",
    "timeZone" TEXT,
    "timeFormat" "TimeFormat",
    "dateFormat" "DateFormat",
    "region" TEXT,
    "language" "Language" NOT NULL DEFAULT 'ENGLISH',
    "showBasicProfile" BOOLEAN NOT NULL DEFAULT true,
    "showContactDetails" BOOLEAN NOT NULL DEFAULT false,
    "userId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "UserPreferences_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "UserPreferences_userId_key" ON "UserPreferences"("userId");

-- AddForeignKey
ALTER TABLE "UserPreferences" ADD CONSTRAINT "UserPreferences_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
