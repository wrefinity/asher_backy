-- AlterTable
ALTER TABLE "Email" ADD COLUMN     "parentEmailId" TEXT,
ADD COLUMN     "threadId" TEXT;

-- AddForeignKey
ALTER TABLE "Email" ADD CONSTRAINT "Email_parentEmailId_fkey" FOREIGN KEY ("parentEmailId") REFERENCES "Email"("id") ON DELETE SET NULL ON UPDATE CASCADE;
