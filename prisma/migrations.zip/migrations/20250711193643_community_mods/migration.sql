/*
  Warnings:

  - You are about to drop the column `userId` on the `CommunityMember` table. All the data in the column will be lost.
  - You are about to drop the column `category` on the `CommunityPost` table. All the data in the column will be lost.
  - You are about to drop the column `communityId` on the `CommunityPost` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `CommunityPostLike` table. All the data in the column will be lost.
  - You are about to drop the column `userAgent` on the `CommunityPostView` table. All the data in the column will be lost.
  - You are about to drop the column `userId` on the `CommunityPostView` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[communityId,usersId]` on the table `CommunityMember` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[postId,usersId]` on the table `CommunityPostLike` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[postId,usersId]` on the table `CommunityPostView` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `usersId` to the `CommunityMember` table without a default value. This is not possible if the table is not empty.
  - Added the required column `categoryId` to the `CommunityPost` table without a default value. This is not possible if the table is not empty.
  - Added the required column `usersId` to the `CommunityPostLike` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "CommunityMember" DROP CONSTRAINT "CommunityMember_userId_fkey";

-- DropForeignKey
ALTER TABLE "CommunityPost" DROP CONSTRAINT "CommunityPost_communityId_fkey";

-- DropForeignKey
ALTER TABLE "CommunityPostLike" DROP CONSTRAINT "CommunityPostLike_userId_fkey";

-- DropForeignKey
ALTER TABLE "CommunityPostView" DROP CONSTRAINT "CommunityPostView_userId_fkey";

-- DropIndex
DROP INDEX "CommunityMember_communityId_userId_key";

-- DropIndex
DROP INDEX "CommunityMember_userId_idx";

-- DropIndex
DROP INDEX "CommunityPost_category_idx";

-- DropIndex
DROP INDEX "CommunityPost_communityId_idx";

-- DropIndex
DROP INDEX "CommunityPostLike_postId_userId_key";

-- DropIndex
DROP INDEX "CommunityPostView_postId_userId_key";

-- AlterTable
ALTER TABLE "Community" ADD COLUMN     "forumCount" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "memberCount" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "postCount" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "CommunityMember" DROP COLUMN "userId",
ADD COLUMN     "usersId" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "CommunityPost" DROP COLUMN "category",
DROP COLUMN "communityId",
ADD COLUMN     "categoryId" TEXT NOT NULL,
ADD COLUMN     "engagement" DOUBLE PRECISION NOT NULL DEFAULT 0,
ADD COLUMN     "sharesCount" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "CommunityPostLike" DROP COLUMN "userId",
ADD COLUMN     "usersId" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "CommunityPostView" DROP COLUMN "userAgent",
DROP COLUMN "userId",
ADD COLUMN     "usersAgent" TEXT,
ADD COLUMN     "usersId" TEXT;

-- CreateTable
CREATE TABLE "Forum" (
    "id" TEXT NOT NULL,
    "communityId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "description" TEXT,
    "order" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "postCount" INTEGER NOT NULL DEFAULT 0,
    "threadCount" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "Forum_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "ForumCategory" (
    "id" TEXT NOT NULL,
    "forumId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "description" TEXT,
    "order" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "postCount" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "ForumCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommunityPostShare" (
    "id" TEXT NOT NULL,
    "postId" TEXT NOT NULL,
    "usersId" TEXT NOT NULL,
    "platform" TEXT,
    "sharedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CommunityPostShare_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "CommentLike" (
    "id" TEXT NOT NULL,
    "commentId" TEXT NOT NULL,
    "usersId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CommentLike_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DiscussionThread" (
    "id" TEXT NOT NULL,
    "forumId" TEXT NOT NULL,
    "authorId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "slug" TEXT NOT NULL,
    "tags" TEXT[],
    "pinned" BOOLEAN NOT NULL DEFAULT false,
    "locked" BOOLEAN NOT NULL DEFAULT false,
    "viewsCount" INTEGER NOT NULL DEFAULT 0,
    "commentsCount" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DiscussionThread_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DiscussionComment" (
    "id" TEXT NOT NULL,
    "threadId" TEXT NOT NULL,
    "authorId" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "parentCommentId" TEXT,
    "depth" INTEGER NOT NULL DEFAULT 0,
    "likesCount" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DiscussionComment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DiscussionCommentLike" (
    "id" TEXT NOT NULL,
    "commentId" TEXT NOT NULL,
    "usersId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "DiscussionCommentLike_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_CommunityToCommunityPost" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE INDEX "Forum_slug_idx" ON "Forum"("slug");

-- CreateIndex
CREATE INDEX "Forum_communityId_idx" ON "Forum"("communityId");

-- CreateIndex
CREATE INDEX "ForumCategory_slug_idx" ON "ForumCategory"("slug");

-- CreateIndex
CREATE INDEX "ForumCategory_forumId_idx" ON "ForumCategory"("forumId");

-- CreateIndex
CREATE INDEX "CommunityPostShare_postId_idx" ON "CommunityPostShare"("postId");

-- CreateIndex
CREATE INDEX "CommunityPostShare_usersId_idx" ON "CommunityPostShare"("usersId");

-- CreateIndex
CREATE UNIQUE INDEX "CommentLike_commentId_usersId_key" ON "CommentLike"("commentId", "usersId");

-- CreateIndex
CREATE UNIQUE INDEX "DiscussionThread_slug_key" ON "DiscussionThread"("slug");

-- CreateIndex
CREATE INDEX "DiscussionThread_forumId_idx" ON "DiscussionThread"("forumId");

-- CreateIndex
CREATE INDEX "DiscussionThread_authorId_idx" ON "DiscussionThread"("authorId");

-- CreateIndex
CREATE INDEX "DiscussionThread_slug_idx" ON "DiscussionThread"("slug");

-- CreateIndex
CREATE INDEX "DiscussionComment_threadId_idx" ON "DiscussionComment"("threadId");

-- CreateIndex
CREATE INDEX "DiscussionComment_authorId_idx" ON "DiscussionComment"("authorId");

-- CreateIndex
CREATE INDEX "DiscussionComment_parentCommentId_idx" ON "DiscussionComment"("parentCommentId");

-- CreateIndex
CREATE UNIQUE INDEX "DiscussionCommentLike_commentId_usersId_key" ON "DiscussionCommentLike"("commentId", "usersId");

-- CreateIndex
CREATE UNIQUE INDEX "_CommunityToCommunityPost_AB_unique" ON "_CommunityToCommunityPost"("A", "B");

-- CreateIndex
CREATE INDEX "_CommunityToCommunityPost_B_index" ON "_CommunityToCommunityPost"("B");

-- CreateIndex
CREATE INDEX "CommunityMember_usersId_idx" ON "CommunityMember"("usersId");

-- CreateIndex
CREATE UNIQUE INDEX "CommunityMember_communityId_usersId_key" ON "CommunityMember"("communityId", "usersId");

-- CreateIndex
CREATE INDEX "CommunityPost_categoryId_idx" ON "CommunityPost"("categoryId");

-- CreateIndex
CREATE INDEX "CommunityPost_createdAt_idx" ON "CommunityPost"("createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "CommunityPostLike_postId_usersId_key" ON "CommunityPostLike"("postId", "usersId");

-- CreateIndex
CREATE UNIQUE INDEX "CommunityPostView_postId_usersId_key" ON "CommunityPostView"("postId", "usersId");

-- AddForeignKey
ALTER TABLE "CommunityMember" ADD CONSTRAINT "CommunityMember_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Forum" ADD CONSTRAINT "Forum_communityId_fkey" FOREIGN KEY ("communityId") REFERENCES "Community"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ForumCategory" ADD CONSTRAINT "ForumCategory_forumId_fkey" FOREIGN KEY ("forumId") REFERENCES "Forum"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPost" ADD CONSTRAINT "CommunityPost_categoryId_fkey" FOREIGN KEY ("categoryId") REFERENCES "ForumCategory"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostLike" ADD CONSTRAINT "CommunityPostLike_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostView" ADD CONSTRAINT "CommunityPostView_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostShare" ADD CONSTRAINT "CommunityPostShare_postId_fkey" FOREIGN KEY ("postId") REFERENCES "CommunityPost"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostShare" ADD CONSTRAINT "CommunityPostShare_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommentLike" ADD CONSTRAINT "CommentLike_commentId_fkey" FOREIGN KEY ("commentId") REFERENCES "Comment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommentLike" ADD CONSTRAINT "CommentLike_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionThread" ADD CONSTRAINT "DiscussionThread_forumId_fkey" FOREIGN KEY ("forumId") REFERENCES "Forum"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionThread" ADD CONSTRAINT "DiscussionThread_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionComment" ADD CONSTRAINT "DiscussionComment_threadId_fkey" FOREIGN KEY ("threadId") REFERENCES "DiscussionThread"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionComment" ADD CONSTRAINT "DiscussionComment_authorId_fkey" FOREIGN KEY ("authorId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionComment" ADD CONSTRAINT "DiscussionComment_parentCommentId_fkey" FOREIGN KEY ("parentCommentId") REFERENCES "DiscussionComment"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionCommentLike" ADD CONSTRAINT "DiscussionCommentLike_commentId_fkey" FOREIGN KEY ("commentId") REFERENCES "DiscussionComment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionCommentLike" ADD CONSTRAINT "DiscussionCommentLike_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CommunityToCommunityPost" ADD CONSTRAINT "_CommunityToCommunityPost_A_fkey" FOREIGN KEY ("A") REFERENCES "Community"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_CommunityToCommunityPost" ADD CONSTRAINT "_CommunityToCommunityPost_B_fkey" FOREIGN KEY ("B") REFERENCES "CommunityPost"("id") ON DELETE CASCADE ON UPDATE CASCADE;
