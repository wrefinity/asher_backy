/*
  Warnings:

  - A unique constraint covering the columns `[logId]` on the table `PropertyEnquiry` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateEnum
CREATE TYPE "EnquireStatus" AS ENUM ('EXISTING_TENANT', 'NEW_TENANT');

-- AlterTable
ALTER TABLE "Log" ADD COLUMN     "enquireStatus" "EnquireStatus";

-- AlterTable
ALTER TABLE "PropertyEnquiry" ADD COLUMN     "logId" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "PropertyEnquiry_logId_key" ON "PropertyEnquiry"("logId");

-- AddForeignKey
ALTER TABLE "PropertyEnquiry" ADD CONSTRAINT "PropertyEnquiry_logId_fkey" FOREIGN KEY ("logId") REFERENCES "Log"("id") ON DELETE SET NULL ON UPDATE CASCADE;
