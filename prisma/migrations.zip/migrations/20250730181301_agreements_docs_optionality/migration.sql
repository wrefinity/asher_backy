-- AlterTable
ALTER TABLE "AgreementDocument" ALTER COLUMN "documentUrl" DROP NOT NULL,
ALTER COLUMN "documentKey" DROP NOT NULL;
