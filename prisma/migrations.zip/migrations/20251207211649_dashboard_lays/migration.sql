-- AlterTable
ALTER TABLE "UserPreferences" ADD COLUMN     "dashboardLayout" JSONB;
