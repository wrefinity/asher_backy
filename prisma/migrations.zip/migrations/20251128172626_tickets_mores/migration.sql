/*
  Warnings:

  - A unique constraint covering the columns `[inspectionId]` on the table `ChatRoom` will be added. If there are existing duplicate values, this will fail.
  - A unique constraint covering the columns `[ticketCode]` on the table `SupportTicket` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `ticketCode` to the `SupportTicket` table without a default value. This is not possible if the table is not empty.

*/
-- AlterEnum
ALTER TYPE "chatType" ADD VALUE 'INSPECTION';

-- DropForeignKey
ALTER TABLE "inspection" DROP CONSTRAINT "inspection_tenantId_fkey";

-- AlterTable
ALTER TABLE "ChatRoom" ADD COLUMN     "inspectionId" TEXT;

-- AlterTable
ALTER TABLE "DiscussionComment" ADD COLUMN     "flagsCount" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "DiscussionThread" ADD COLUMN     "flagsCount" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "Forum" ADD COLUMN     "floorIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
ADD COLUMN     "individualUserIds" TEXT[] DEFAULT ARRAY[]::TEXT[],
ADD COLUMN     "locationCriteria" JSONB,
ADD COLUMN     "membershipType" TEXT NOT NULL DEFAULT 'INDIVIDUAL',
ADD COLUMN     "propertyIds" TEXT[] DEFAULT ARRAY[]::TEXT[];

-- AlterTable
ALTER TABLE "SupportTicket" ADD COLUMN     "ticketCode" TEXT NOT NULL;

-- AlterTable
ALTER TABLE "inspection" ADD COLUMN     "completedAt" TIMESTAMP(3),
ADD COLUMN     "criticalIssues" INTEGER DEFAULT 0,
ADD COLUMN     "findings" INTEGER DEFAULT 0,
ADD COLUMN     "generalNotes" TEXT,
ADD COLUMN     "inspector" TEXT,
ADD COLUMN     "inspectorId" TEXT,
ADD COLUMN     "overallCondition" TEXT,
ADD COLUMN     "priority" TEXT,
ADD COLUMN     "recommendations" TEXT,
ADD COLUMN     "scheduledDate" TIMESTAMP(3),
ADD COLUMN     "scheduledTime" TEXT,
ADD COLUMN     "status" TEXT DEFAULT 'Scheduled',
ADD COLUMN     "type" TEXT,
ALTER COLUMN "tenantId" DROP NOT NULL,
ALTER COLUMN "score" DROP NOT NULL;

-- AlterTable
ALTER TABLE "properties" ADD COLUMN     "propertyValue" DECIMAL(18,2),
ADD COLUMN     "purchaseType" TEXT;

-- AlterTable
ALTER TABLE "tenants" ADD COLUMN     "agreementInfo" JSONB,
ADD COLUMN     "applicationMetadata" JSONB,
ADD COLUMN     "refereeInfo" JSONB;

-- CreateTable
CREATE TABLE "CommunityPostPin" (
    "id" TEXT NOT NULL,
    "postId" TEXT NOT NULL,
    "usersId" TEXT NOT NULL,
    "pinnedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "CommunityPostPin_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inspection_section" (
    "id" TEXT NOT NULL,
    "inspectionId" TEXT NOT NULL,
    "sectionType" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inspection_section_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inspection_item" (
    "id" TEXT NOT NULL,
    "sectionId" TEXT NOT NULL,
    "itemName" TEXT NOT NULL,
    "condition" TEXT NOT NULL,
    "notes" TEXT,
    "actionRequired" BOOLEAN NOT NULL DEFAULT false,
    "severity" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inspection_item_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inspection_photo" (
    "id" TEXT NOT NULL,
    "itemId" TEXT,
    "sectionId" TEXT,
    "url" TEXT NOT NULL,
    "caption" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "inspection_photo_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inspection_certificate" (
    "id" TEXT NOT NULL,
    "inspectionId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "pdfUrl" TEXT NOT NULL,
    "generatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "generatedBy" TEXT NOT NULL,

    CONSTRAINT "inspection_certificate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "inspection_acknowledgment" (
    "id" TEXT NOT NULL,
    "inspectionId" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "acknowledged" BOOLEAN NOT NULL DEFAULT false,
    "signature" TEXT,
    "comments" TEXT,
    "disputed" BOOLEAN NOT NULL DEFAULT false,
    "acknowledgedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "inspection_acknowledgment_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "notification" (
    "id" TEXT NOT NULL,
    "sourceId" TEXT,
    "destId" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "category" "NotificationCategory",
    "isRead" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "notification_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "FAQ" (
    "id" TEXT NOT NULL,
    "question" TEXT NOT NULL,
    "answer" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "order" INTEGER NOT NULL DEFAULT 0,
    "isPublished" BOOLEAN NOT NULL DEFAULT true,
    "views" INTEGER NOT NULL DEFAULT 0,
    "systemId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT,
    "updatedBy" TEXT,

    CONSTRAINT "FAQ_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "HelpArticle" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "readTime" TEXT NOT NULL,
    "views" INTEGER NOT NULL DEFAULT 0,
    "thumbnail" TEXT,
    "isPublished" BOOLEAN NOT NULL DEFAULT true,
    "systemId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT,
    "updatedBy" TEXT,

    CONSTRAINT "HelpArticle_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "VideoTutorial" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "videoUrl" TEXT NOT NULL,
    "thumbnail" TEXT NOT NULL,
    "duration" TEXT NOT NULL,
    "category" TEXT NOT NULL,
    "views" INTEGER NOT NULL DEFAULT 0,
    "isPublished" BOOLEAN NOT NULL DEFAULT true,
    "systemId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT,
    "updatedBy" TEXT,

    CONSTRAINT "VideoTutorial_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "SupportAgent" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,
    "role" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "SupportAgent_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "TicketMessage" (
    "id" TEXT NOT NULL,
    "ticketId" TEXT NOT NULL,
    "senderId" TEXT NOT NULL,
    "content" TEXT NOT NULL,
    "attachments" TEXT[],
    "isInternal" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "TicketMessage_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "CommunityPostPin_postId_usersId_key" ON "CommunityPostPin"("postId", "usersId");

-- CreateIndex
CREATE INDEX "inspection_section_inspectionId_idx" ON "inspection_section"("inspectionId");

-- CreateIndex
CREATE INDEX "inspection_section_inspectionId_sectionType_idx" ON "inspection_section"("inspectionId", "sectionType");

-- CreateIndex
CREATE INDEX "inspection_item_sectionId_idx" ON "inspection_item"("sectionId");

-- CreateIndex
CREATE INDEX "inspection_item_actionRequired_idx" ON "inspection_item"("actionRequired");

-- CreateIndex
CREATE INDEX "inspection_item_severity_idx" ON "inspection_item"("severity");

-- CreateIndex
CREATE INDEX "inspection_photo_itemId_idx" ON "inspection_photo"("itemId");

-- CreateIndex
CREATE INDEX "inspection_photo_sectionId_idx" ON "inspection_photo"("sectionId");

-- CreateIndex
CREATE INDEX "inspection_certificate_inspectionId_idx" ON "inspection_certificate"("inspectionId");

-- CreateIndex
CREATE INDEX "inspection_certificate_inspectionId_type_idx" ON "inspection_certificate"("inspectionId", "type");

-- CreateIndex
CREATE UNIQUE INDEX "inspection_acknowledgment_inspectionId_key" ON "inspection_acknowledgment"("inspectionId");

-- CreateIndex
CREATE INDEX "inspection_acknowledgment_inspectionId_idx" ON "inspection_acknowledgment"("inspectionId");

-- CreateIndex
CREATE INDEX "inspection_acknowledgment_tenantId_idx" ON "inspection_acknowledgment"("tenantId");

-- CreateIndex
CREATE INDEX "inspection_acknowledgment_acknowledged_idx" ON "inspection_acknowledgment"("acknowledged");

-- CreateIndex
CREATE INDEX "notification_destId_idx" ON "notification"("destId");

-- CreateIndex
CREATE INDEX "notification_destId_isRead_idx" ON "notification"("destId", "isRead");

-- CreateIndex
CREATE INDEX "notification_createdAt_idx" ON "notification"("createdAt");

-- CreateIndex
CREATE INDEX "FAQ_category_idx" ON "FAQ"("category");

-- CreateIndex
CREATE INDEX "FAQ_isPublished_idx" ON "FAQ"("isPublished");

-- CreateIndex
CREATE INDEX "FAQ_order_idx" ON "FAQ"("order");

-- CreateIndex
CREATE INDEX "FAQ_createdAt_idx" ON "FAQ"("createdAt");

-- CreateIndex
CREATE INDEX "FAQ_systemId_idx" ON "FAQ"("systemId");

-- CreateIndex
CREATE INDEX "HelpArticle_category_idx" ON "HelpArticle"("category");

-- CreateIndex
CREATE INDEX "HelpArticle_isPublished_idx" ON "HelpArticle"("isPublished");

-- CreateIndex
CREATE INDEX "HelpArticle_createdAt_idx" ON "HelpArticle"("createdAt");

-- CreateIndex
CREATE INDEX "HelpArticle_views_idx" ON "HelpArticle"("views");

-- CreateIndex
CREATE INDEX "HelpArticle_systemId_idx" ON "HelpArticle"("systemId");

-- CreateIndex
CREATE INDEX "VideoTutorial_category_idx" ON "VideoTutorial"("category");

-- CreateIndex
CREATE INDEX "VideoTutorial_isPublished_idx" ON "VideoTutorial"("isPublished");

-- CreateIndex
CREATE INDEX "VideoTutorial_createdAt_idx" ON "VideoTutorial"("createdAt");

-- CreateIndex
CREATE INDEX "VideoTutorial_views_idx" ON "VideoTutorial"("views");

-- CreateIndex
CREATE INDEX "VideoTutorial_systemId_idx" ON "VideoTutorial"("systemId");

-- CreateIndex
CREATE UNIQUE INDEX "SupportAgent_userId_key" ON "SupportAgent"("userId");

-- CreateIndex
CREATE INDEX "SupportAgent_userId_idx" ON "SupportAgent"("userId");

-- CreateIndex
CREATE INDEX "SupportAgent_isActive_idx" ON "SupportAgent"("isActive");

-- CreateIndex
CREATE INDEX "TicketMessage_ticketId_idx" ON "TicketMessage"("ticketId");

-- CreateIndex
CREATE INDEX "TicketMessage_senderId_idx" ON "TicketMessage"("senderId");

-- CreateIndex
CREATE UNIQUE INDEX "ChatRoom_inspectionId_key" ON "ChatRoom"("inspectionId");

-- CreateIndex
CREATE INDEX "ChatRoom_inspectionId_idx" ON "ChatRoom"("inspectionId");

-- CreateIndex
CREATE INDEX "Forum_membershipType_idx" ON "Forum"("membershipType");

-- CreateIndex
CREATE UNIQUE INDEX "SupportTicket_ticketCode_key" ON "SupportTicket"("ticketCode");

-- CreateIndex
CREATE INDEX "SupportTicket_ticketCode_idx" ON "SupportTicket"("ticketCode");

-- CreateIndex
CREATE INDEX "inspection_propertyId_idx" ON "inspection"("propertyId");

-- CreateIndex
CREATE INDEX "inspection_status_idx" ON "inspection"("status");

-- CreateIndex
CREATE INDEX "inspection_scheduledDate_idx" ON "inspection"("scheduledDate");

-- CreateIndex
CREATE INDEX "inspection_type_idx" ON "inspection"("type");

-- AddForeignKey
ALTER TABLE "ChatRoom" ADD CONSTRAINT "ChatRoom_inspectionId_fkey" FOREIGN KEY ("inspectionId") REFERENCES "inspection"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostPin" ADD CONSTRAINT "CommunityPostPin_postId_fkey" FOREIGN KEY ("postId") REFERENCES "CommunityPost"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CommunityPostPin" ADD CONSTRAINT "CommunityPostPin_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection_section" ADD CONSTRAINT "inspection_section_inspectionId_fkey" FOREIGN KEY ("inspectionId") REFERENCES "inspection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection_item" ADD CONSTRAINT "inspection_item_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "inspection_section"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection_photo" ADD CONSTRAINT "inspection_photo_itemId_fkey" FOREIGN KEY ("itemId") REFERENCES "inspection_item"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection_photo" ADD CONSTRAINT "inspection_photo_sectionId_fkey" FOREIGN KEY ("sectionId") REFERENCES "inspection_section"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection_certificate" ADD CONSTRAINT "inspection_certificate_inspectionId_fkey" FOREIGN KEY ("inspectionId") REFERENCES "inspection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection_certificate" ADD CONSTRAINT "inspection_certificate_generatedBy_fkey" FOREIGN KEY ("generatedBy") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection_acknowledgment" ADD CONSTRAINT "inspection_acknowledgment_inspectionId_fkey" FOREIGN KEY ("inspectionId") REFERENCES "inspection"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection_acknowledgment" ADD CONSTRAINT "inspection_acknowledgment_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "inspection" ADD CONSTRAINT "inspection_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "notification" ADD CONSTRAINT "notification_sourceId_fkey" FOREIGN KEY ("sourceId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "notification" ADD CONSTRAINT "notification_destId_fkey" FOREIGN KEY ("destId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FAQ" ADD CONSTRAINT "FAQ_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "FAQ" ADD CONSTRAINT "FAQ_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HelpArticle" ADD CONSTRAINT "HelpArticle_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "HelpArticle" ADD CONSTRAINT "HelpArticle_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VideoTutorial" ADD CONSTRAINT "VideoTutorial_createdBy_fkey" FOREIGN KEY ("createdBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VideoTutorial" ADD CONSTRAINT "VideoTutorial_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupportAgent" ADD CONSTRAINT "SupportAgent_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TicketMessage" ADD CONSTRAINT "TicketMessage_ticketId_fkey" FOREIGN KEY ("ticketId") REFERENCES "SupportTicket"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "TicketMessage" ADD CONSTRAINT "TicketMessage_senderId_fkey" FOREIGN KEY ("senderId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
