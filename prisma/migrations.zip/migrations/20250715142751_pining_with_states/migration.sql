-- CreateTable
CREATE TABLE "ForumThreadPin" (
    "id" TEXT NOT NULL,
    "threadId" TEXT NOT NULL,
    "usersId" TEXT NOT NULL,
    "pinnedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ForumThreadPin_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ForumThreadPin_threadId_usersId_key" ON "ForumThreadPin"("threadId", "usersId");

-- AddForeignKey
ALTER TABLE "ForumThreadPin" ADD CONSTRAINT "ForumThreadPin_threadId_fkey" FOREIGN KEY ("threadId") REFERENCES "DiscussionThread"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ForumThreadPin" ADD CONSTRAINT "ForumThreadPin_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
