-- DropIndex
DROP INDEX "tenants_userId_key";

-- DropIndex
DROP INDEX "tenants_userId_propertyId_key";
