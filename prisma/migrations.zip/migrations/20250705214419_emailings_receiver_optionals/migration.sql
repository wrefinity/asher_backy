-- DropForeignKey
ALTER TABLE "Email" DROP CONSTRAINT "Email_receiverId_fkey";

-- AlterTable
ALTER TABLE "Email" ALTER COLUMN "receiverId" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "Email" ADD CONSTRAINT "Email_receiverId_fkey" FOREIGN KEY ("receiverId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;
