-- CreateEnum
CREATE TYPE "RenewalStatus" AS ENUM ('PENDING', 'ACCEPTED', 'REJECTED', 'COUNTER_OFFER', 'EXPIRED');

-- CreateTable
CREATE TABLE "LeaseRenewal" (
    "id" TEXT NOT NULL,
    "tenantId" TEXT NOT NULL,
    "propertyId" TEXT NOT NULL,
    "currentRent" DECIMAL(10,2) NOT NULL,
    "proposedRent" DECIMAL(10,2) NOT NULL,
    "renewalTerms" JSONB NOT NULL,
    "status" "RenewalStatus" NOT NULL DEFAULT 'PENDING',
    "message" TEXT,
    "proposedBy" TEXT NOT NULL,
    "proposedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "respondedBy" TEXT,
    "respondedAt" TIMESTAMP(3),
    "counterOffer" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LeaseRenewal_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "LandlordEvent" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "startTime" TIMESTAMP(3) NOT NULL,
    "endTime" TIMESTAMP(3) NOT NULL,
    "date" TIMESTAMP(3) NOT NULL,
    "color" TEXT DEFAULT 'blue',
    "landlordId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "LandlordEvent_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "LeaseRenewal_tenantId_status_idx" ON "LeaseRenewal"("tenantId", "status");

-- CreateIndex
CREATE INDEX "LeaseRenewal_propertyId_status_idx" ON "LeaseRenewal"("propertyId", "status");

-- CreateIndex
CREATE INDEX "LandlordEvent_date_idx" ON "LandlordEvent"("date");

-- CreateIndex
CREATE INDEX "LandlordEvent_landlordId_idx" ON "LandlordEvent"("landlordId");

-- CreateIndex
CREATE INDEX "LandlordEvent_startTime_idx" ON "LandlordEvent"("startTime");

-- AddForeignKey
ALTER TABLE "LeaseRenewal" ADD CONSTRAINT "LeaseRenewal_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LeaseRenewal" ADD CONSTRAINT "LeaseRenewal_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LandlordEvent" ADD CONSTRAINT "LandlordEvent_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE CASCADE ON UPDATE CASCADE;
