-- CreateIndex
CREATE INDEX "AdditionalRule_shortletId_idx" ON "AdditionalRule"("shortletId");

-- CreateIndex
CREATE INDEX "Booking_propertyId_checkInDate_checkOutDate_idx" ON "Booking"("propertyId", "checkInDate", "checkOutDate");

-- CreateIndex
CREATE INDEX "Booking_userId_createdAt_idx" ON "Booking"("userId", "createdAt");

-- CreateIndex
CREATE INDEX "Booking_status_paymentStatus_idx" ON "Booking"("status", "paymentStatus");

-- CreateIndex
CREATE INDEX "Booking_checkInDate_checkOutDate_idx" ON "Booking"("checkInDate", "checkOutDate");

-- CreateIndex
CREATE INDEX "Booking_guestEmail_idx" ON "Booking"("guestEmail");

-- CreateIndex
CREATE INDEX "Booking_guestPhone_idx" ON "Booking"("guestPhone");

-- CreateIndex
CREATE INDEX "Booking_createdAt_idx" ON "Booking"("createdAt");

-- CreateIndex
CREATE INDEX "Booking_unitConfigurationId_roomDetailId_idx" ON "Booking"("unitConfigurationId", "roomDetailId");

-- CreateIndex
CREATE INDEX "Booking_cancellationPolicy_isRefundable_idx" ON "Booking"("cancellationPolicy", "isRefundable");

-- CreateIndex
CREATE INDEX "Booking_propertyId_status_checkInDate_idx" ON "Booking"("propertyId", "status", "checkInDate");

-- CreateIndex
CREATE INDEX "Booking_userId_status_createdAt_idx" ON "Booking"("userId", "status", "createdAt");

-- CreateIndex
CREATE INDEX "Booking_checkInDate_status_paymentStatus_idx" ON "Booking"("checkInDate", "status", "paymentStatus");

-- CreateIndex
CREATE INDEX "CommercialProperty_buildingClass_idx" ON "CommercialProperty"("buildingClass");

-- CreateIndex
CREATE INDEX "CommercialProperty_totalArea_areaUnit_idx" ON "CommercialProperty"("totalArea", "areaUnit");

-- CreateIndex
CREATE INDEX "CommercialProperty_parkingSpaces_idx" ON "CommercialProperty"("parkingSpaces");

-- CreateIndex
CREATE INDEX "CommercialProperty_officeLayout_idx" ON "CommercialProperty"("officeLayout");

-- CreateIndex
CREATE INDEX "CommercialProperty_availableFrom_idx" ON "CommercialProperty"("availableFrom");

-- CreateIndex
CREATE INDEX "CommercialProperty_leaseTermUnit_minimumLeaseTerm_idx" ON "CommercialProperty"("leaseTermUnit", "minimumLeaseTerm");

-- CreateIndex
CREATE INDEX "CommercialProperty_hasGreenCertification_idx" ON "CommercialProperty"("hasGreenCertification");

-- CreateIndex
CREATE INDEX "CommercialProperty_epcRating_idx" ON "CommercialProperty"("epcRating");

-- CreateIndex
CREATE INDEX "CommercialProperty_totalFloors_floorLevel_idx" ON "CommercialProperty"("totalFloors", "floorLevel");

-- CreateIndex
CREATE INDEX "CommercialProperty_workstations_meetingRooms_idx" ON "CommercialProperty"("workstations", "meetingRooms");

-- CreateIndex
CREATE INDEX "CommercialProperty_buildingClass_totalArea_availableFrom_idx" ON "CommercialProperty"("buildingClass", "totalArea", "availableFrom");

-- CreateIndex
CREATE INDEX "CommercialProperty_parkingSpaces_officeLayout_hasGreenCerti_idx" ON "CommercialProperty"("parkingSpaces", "officeLayout", "hasGreenCertification");

-- CreateIndex
CREATE INDEX "CommercialPropertyFloor_propertyId_available_idx" ON "CommercialPropertyFloor"("propertyId", "available");

-- CreateIndex
CREATE INDEX "CommercialPropertyFloor_floorNumber_idx" ON "CommercialPropertyFloor"("floorNumber");

-- CreateIndex
CREATE INDEX "CommercialPropertyFloor_available_floorNumber_idx" ON "CommercialPropertyFloor"("available", "floorNumber");

-- CreateIndex
CREATE INDEX "CommercialPropertyFloor_price_idx" ON "CommercialPropertyFloor"("price");

-- CreateIndex
CREATE INDEX "HostLanguage_shortletId_idx" ON "HostLanguage"("shortletId");

-- CreateIndex
CREATE INDEX "HostLanguage_language_idx" ON "HostLanguage"("language");

-- CreateIndex
CREATE INDEX "PropertySpecification_propertyId_specificationType_isActive_idx" ON "PropertySpecification"("propertyId", "specificationType", "isActive");

-- CreateIndex
CREATE INDEX "PropertySpecification_specificationType_propertySubType_isA_idx" ON "PropertySpecification"("specificationType", "propertySubType", "isActive");

-- CreateIndex
CREATE INDEX "PropertySpecification_residentialId_idx" ON "PropertySpecification"("residentialId");

-- CreateIndex
CREATE INDEX "PropertySpecification_commercialId_idx" ON "PropertySpecification"("commercialId");

-- CreateIndex
CREATE INDEX "PropertySpecification_shortletId_idx" ON "PropertySpecification"("shortletId");

-- CreateIndex
CREATE INDEX "PropertySpecification_isActive_fromDate_toDate_idx" ON "PropertySpecification"("isActive", "fromDate", "toDate");

-- CreateIndex
CREATE INDEX "PropertySpecification_createdAt_idx" ON "PropertySpecification"("createdAt");

-- CreateIndex
CREATE INDEX "ResidentialProperty_status_idx" ON "ResidentialProperty"("status");

-- CreateIndex
CREATE INDEX "ResidentialProperty_bedrooms_bathrooms_idx" ON "ResidentialProperty"("bedrooms", "bathrooms");

-- CreateIndex
CREATE INDEX "ResidentialProperty_furnished_idx" ON "ResidentialProperty"("furnished");

-- CreateIndex
CREATE INDEX "ResidentialProperty_yearBuilt_idx" ON "ResidentialProperty"("yearBuilt");

-- CreateIndex
CREATE INDEX "ResidentialProperty_totalArea_idx" ON "ResidentialProperty"("totalArea");

-- CreateIndex
CREATE INDEX "ResidentialProperty_isHMO_isHMOLicenced_idx" ON "ResidentialProperty"("isHMO", "isHMOLicenced");

-- CreateIndex
CREATE INDEX "ResidentialProperty_availableFrom_idx" ON "ResidentialProperty"("availableFrom");

-- CreateIndex
CREATE INDEX "ResidentialProperty_epcRating_energyEfficiencyRating_idx" ON "ResidentialProperty"("epcRating", "energyEfficiencyRating");

-- CreateIndex
CREATE INDEX "ResidentialProperty_status_bedrooms_bathrooms_furnished_idx" ON "ResidentialProperty"("status", "bedrooms", "bathrooms", "furnished");

-- CreateIndex
CREATE INDEX "ResidentialProperty_yearBuilt_totalArea_status_idx" ON "ResidentialProperty"("yearBuilt", "totalArea", "status");

-- CreateIndex
CREATE INDEX "RoomDetail_residentialPropertyId_isDeleted_availability_idx" ON "RoomDetail"("residentialPropertyId", "isDeleted", "availability");

-- CreateIndex
CREATE INDEX "RoomDetail_commercialPropertyId_isDeleted_availability_idx" ON "RoomDetail"("commercialPropertyId", "isDeleted", "availability");

-- CreateIndex
CREATE INDEX "RoomDetail_shortletPropertyId_isDeleted_availability_idx" ON "RoomDetail"("shortletPropertyId", "isDeleted", "availability");

-- CreateIndex
CREATE INDEX "RoomDetail_unitId_availability_isListed_idx" ON "RoomDetail"("unitId", "availability", "isListed");

-- CreateIndex
CREATE INDEX "RoomDetail_availability_isListed_isDeleted_idx" ON "RoomDetail"("availability", "isListed", "isDeleted");

-- CreateIndex
CREATE INDEX "RoomDetail_roomName_idx" ON "RoomDetail"("roomName");

-- CreateIndex
CREATE INDEX "RoomDetail_price_priceFrequency_idx" ON "RoomDetail"("price", "priceFrequency");

-- CreateIndex
CREATE INDEX "RoomDetail_ensuite_furnished_idx" ON "RoomDetail"("ensuite", "furnished");

-- CreateIndex
CREATE INDEX "RoomDetail_residentialPropertyId_availability_ensuite_furni_idx" ON "RoomDetail"("residentialPropertyId", "availability", "ensuite", "furnished");

-- CreateIndex
CREATE INDEX "RoomDetail_shortletPropertyId_availability_isListed_price_idx" ON "RoomDetail"("shortletPropertyId", "availability", "isListed", "price");

-- CreateIndex
CREATE INDEX "SeasonalPricing_propertyId_startDate_endDate_idx" ON "SeasonalPricing"("propertyId", "startDate", "endDate");

-- CreateIndex
CREATE INDEX "SeasonalPricing_startDate_endDate_idx" ON "SeasonalPricing"("startDate", "endDate");

-- CreateIndex
CREATE INDEX "SeasonalPricing_price_idx" ON "SeasonalPricing"("price");

-- CreateIndex
CREATE INDEX "SharedFacilities_residentialPropertyId_idx" ON "SharedFacilities"("residentialPropertyId");

-- CreateIndex
CREATE INDEX "SharedFacilities_commercialPropertyId_idx" ON "SharedFacilities"("commercialPropertyId");

-- CreateIndex
CREATE INDEX "SharedFacilities_shortletPropertyId_idx" ON "SharedFacilities"("shortletPropertyId");

-- CreateIndex
CREATE INDEX "SharedFacilities_parking_garden_garage_idx" ON "SharedFacilities"("parking", "garden", "garage");

-- CreateIndex
CREATE INDEX "SharedFacilities_kitchen_bathroom_laundry_idx" ON "SharedFacilities"("kitchen", "bathroom", "laundry");

-- CreateIndex
CREATE INDEX "ShortletProperty_availableFrom_availableTo_idx" ON "ShortletProperty"("availableFrom", "availableTo");

-- CreateIndex
CREATE INDEX "ShortletProperty_bedrooms_bathrooms_maxGuests_idx" ON "ShortletProperty"("bedrooms", "bathrooms", "maxGuests");

-- CreateIndex
CREATE INDEX "ShortletProperty_basePrice_idx" ON "ShortletProperty"("basePrice");

-- CreateIndex
CREATE INDEX "ShortletProperty_furnished_idx" ON "ShortletProperty"("furnished");

-- CreateIndex
CREATE INDEX "ShortletProperty_instantBooking_idx" ON "ShortletProperty"("instantBooking");

-- CreateIndex
CREATE INDEX "ShortletProperty_minStayDays_maxStayDays_idx" ON "ShortletProperty"("minStayDays", "maxStayDays");

-- CreateIndex
CREATE INDEX "ShortletProperty_cancellationPolicy_idx" ON "ShortletProperty"("cancellationPolicy");

-- CreateIndex
CREATE INDEX "ShortletProperty_isSuperhost_idx" ON "ShortletProperty"("isSuperhost");

-- CreateIndex
CREATE INDEX "ShortletProperty_allowPets_allowSmoking_allowParties_idx" ON "ShortletProperty"("allowPets", "allowSmoking", "allowParties");

-- CreateIndex
CREATE INDEX "ShortletProperty_availableFrom_availableTo_bedrooms_basePri_idx" ON "ShortletProperty"("availableFrom", "availableTo", "bedrooms", "basePrice");

-- CreateIndex
CREATE INDEX "ShortletProperty_isSuperhost_instantBooking_cancellationPol_idx" ON "ShortletProperty"("isSuperhost", "instantBooking", "cancellationPolicy");

-- CreateIndex
CREATE INDEX "SuitableUse_commercialPropertyId_idx" ON "SuitableUse"("commercialPropertyId");

-- CreateIndex
CREATE INDEX "SuitableUse_name_idx" ON "SuitableUse"("name");

-- CreateIndex
CREATE INDEX "UnavailableDate_shortletId_date_idx" ON "UnavailableDate"("shortletId", "date");

-- CreateIndex
CREATE INDEX "UnavailableDate_date_idx" ON "UnavailableDate"("date");

-- CreateIndex
CREATE INDEX "UnitConfiguration_residentialPropertyId_isDeleted_availabil_idx" ON "UnitConfiguration"("residentialPropertyId", "isDeleted", "availability");

-- CreateIndex
CREATE INDEX "UnitConfiguration_commercialPropertyId_isDeleted_availabili_idx" ON "UnitConfiguration"("commercialPropertyId", "isDeleted", "availability");

-- CreateIndex
CREATE INDEX "UnitConfiguration_availability_isListed_isDeleted_idx" ON "UnitConfiguration"("availability", "isListed", "isDeleted");

-- CreateIndex
CREATE INDEX "UnitConfiguration_unitType_availability_isListed_idx" ON "UnitConfiguration"("unitType", "availability", "isListed");

-- CreateIndex
CREATE INDEX "UnitConfiguration_bedrooms_bathrooms_availability_idx" ON "UnitConfiguration"("bedrooms", "bathrooms", "availability");

-- CreateIndex
CREATE INDEX "UnitConfiguration_price_priceFrequency_idx" ON "UnitConfiguration"("price", "priceFrequency");

-- CreateIndex
CREATE INDEX "UnitConfiguration_floorNumber_idx" ON "UnitConfiguration"("floorNumber");

-- CreateIndex
CREATE INDEX "UnitConfiguration_ensuite_furnished_idx" ON "UnitConfiguration"("ensuite", "furnished");

-- CreateIndex
CREATE INDEX "UnitConfiguration_residentialPropertyId_availability_bedroo_idx" ON "UnitConfiguration"("residentialPropertyId", "availability", "bedrooms", "bathrooms");

-- CreateIndex
CREATE INDEX "UnitConfiguration_commercialPropertyId_availability_unitTyp_idx" ON "UnitConfiguration"("commercialPropertyId", "availability", "unitType");

-- CreateIndex
CREATE INDEX "properties_landlordId_isDeleted_isListed_idx" ON "properties"("landlordId", "isDeleted", "isListed");

-- CreateIndex
CREATE INDEX "properties_agencyId_isDeleted_isListed_idx" ON "properties"("agencyId", "isDeleted", "isListed");

-- CreateIndex
CREATE INDEX "properties_stateId_city_isDeleted_idx" ON "properties"("stateId", "city", "isDeleted");

-- CreateIndex
CREATE INDEX "properties_city_availability_isListed_idx" ON "properties"("city", "availability", "isListed");

-- CreateIndex
CREATE INDEX "properties_availability_isListed_isDeleted_idx" ON "properties"("availability", "isListed", "isDeleted");

-- CreateIndex
CREATE INDEX "properties_price_priceFrequency_availability_idx" ON "properties"("price", "priceFrequency", "availability");

-- CreateIndex
CREATE INDEX "properties_specificationType_isListed_isDeleted_idx" ON "properties"("specificationType", "isListed", "isDeleted");

-- CreateIndex
CREATE INDEX "properties_createdAt_idx" ON "properties"("createdAt");

-- CreateIndex
CREATE INDEX "properties_updatedAt_idx" ON "properties"("updatedAt");

-- CreateIndex
CREATE INDEX "properties_isListed_availability_createdAt_idx" ON "properties"("isListed", "availability", "createdAt");

-- CreateIndex
CREATE INDEX "properties_longitude_latitude_idx" ON "properties"("longitude", "latitude");

-- CreateIndex
CREATE INDEX "properties_zipcode_city_idx" ON "properties"("zipcode", "city");

-- CreateIndex
CREATE INDEX "properties_yearBuilt_idx" ON "properties"("yearBuilt");

-- CreateIndex
CREATE INDEX "properties_marketValue_idx" ON "properties"("marketValue");

-- CreateIndex
CREATE INDEX "properties_name_idx" ON "properties"("name");

-- CreateIndex
CREATE INDEX "properties_address_idx" ON "properties"("address");

-- CreateIndex
CREATE INDEX "properties_landlordId_isDeleted_availability_createdAt_idx" ON "properties"("landlordId", "isDeleted", "availability", "createdAt");

-- CreateIndex
CREATE INDEX "properties_city_specificationType_availability_price_idx" ON "properties"("city", "specificationType", "availability", "price");

-- CreateIndex
CREATE INDEX "propertyListingHistory_propertyId_isActive_onListing_idx" ON "propertyListingHistory"("propertyId", "isActive", "onListing");

-- CreateIndex
CREATE INDEX "propertyListingHistory_isActive_onListing_createdAt_idx" ON "propertyListingHistory"("isActive", "onListing", "createdAt");

-- CreateIndex
CREATE INDEX "propertyListingHistory_availableFrom_availableTo_idx" ON "propertyListingHistory"("availableFrom", "availableTo");

-- CreateIndex
CREATE INDEX "propertyListingHistory_price_priceFrequency_idx" ON "propertyListingHistory"("price", "priceFrequency");

-- CreateIndex
CREATE INDEX "propertyListingHistory_listAs_propertySubType_idx" ON "propertyListingHistory"("listAs", "propertySubType");

-- CreateIndex
CREATE INDEX "propertyListingHistory_createdAt_idx" ON "propertyListingHistory"("createdAt");

-- CreateIndex
CREATE INDEX "propertyListingHistory_unitId_isActive_idx" ON "propertyListingHistory"("unitId", "isActive");

-- CreateIndex
CREATE INDEX "propertyListingHistory_roomId_isActive_idx" ON "propertyListingHistory"("roomId", "isActive");

-- CreateIndex
CREATE INDEX "propertyListingHistory_minStayDays_maxStayDays_idx" ON "propertyListingHistory"("minStayDays", "maxStayDays");

-- CreateIndex
CREATE INDEX "propertyListingHistory_isActive_onListing_propertyId_create_idx" ON "propertyListingHistory"("isActive", "onListing", "propertyId", "createdAt");

-- CreateIndex
CREATE INDEX "propertySettings_landlordId_idx" ON "propertySettings"("landlordId");

-- CreateIndex
CREATE INDEX "propertySettings_propertyId_idx" ON "propertySettings"("propertyId");

-- CreateIndex
CREATE INDEX "propertySettings_settingType_idx" ON "propertySettings"("settingType");

-- CreateIndex
CREATE INDEX "propertySettings_createdAt_idx" ON "propertySettings"("createdAt");
