-- AlterTable
ALTER TABLE "maintenanceWhitelist" ADD COLUMN     "roomId" TEXT,
ADD COLUMN     "unitId" TEXT;

-- AddForeignKey
ALTER TABLE "maintenanceWhitelist" ADD CONSTRAINT "maintenanceWhitelist_unitId_fkey" FOREIGN KEY ("unitId") REFERENCES "UnitConfiguration"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenanceWhitelist" ADD CONSTRAINT "maintenanceWhitelist_roomId_fkey" FOREIGN KEY ("roomId") REFERENCES "RoomDetail"("id") ON DELETE SET NULL ON UPDATE CASCADE;
