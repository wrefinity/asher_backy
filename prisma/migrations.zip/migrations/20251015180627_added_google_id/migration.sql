-- AlterTable
ALTER TABLE "users" ADD COLUMN     "googleId" TEXT;
