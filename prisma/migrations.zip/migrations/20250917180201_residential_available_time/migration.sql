-- AlterTable
ALTER TABLE "ResidentialProperty" ADD COLUMN     "availableFrom" TIMESTAMP(3);
