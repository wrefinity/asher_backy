/*
  Warnings:

  - You are about to drop the `profileDocument` table. If the table is not empty, all the data it contains will be lost.

*/
-- DropForeignKey
ALTER TABLE "profileDocument" DROP CONSTRAINT "profileDocument_profileId_fkey";

-- DropTable
DROP TABLE "profileDocument";

-- CreateTable
CREATE TABLE "vendorDocument" (
    "id" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "vendorId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "vendorDocument_pkey" PRIMARY KEY ("id")
);

-- AddForeignKey
ALTER TABLE "vendorDocument" ADD CONSTRAINT "vendorDocument_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
