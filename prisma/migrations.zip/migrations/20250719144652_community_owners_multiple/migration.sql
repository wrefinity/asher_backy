-- DropForeignKey
ALTER TABLE "SupportTicket" DROP CONSTRAINT "SupportTicket_raisedById_fkey";

-- DropIndex
DROP INDEX "Community_ownerId_key";

-- AlterTable
ALTER TABLE "SupportTicket" ADD COLUMN     "raisedByTenantId" TEXT,
ALTER COLUMN "raisedById" DROP NOT NULL;

-- AddForeignKey
ALTER TABLE "SupportTicket" ADD CONSTRAINT "SupportTicket_raisedById_fkey" FOREIGN KEY ("raisedById") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "SupportTicket" ADD CONSTRAINT "SupportTicket_raisedByTenantId_fkey" FOREIGN KEY ("raisedByTenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;
