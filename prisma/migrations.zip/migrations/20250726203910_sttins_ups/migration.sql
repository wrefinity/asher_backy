/*
  Warnings:

  - You are about to drop the column `percentageOrAmount` on the `Settings` table. All the data in the column will be lost.
  - You are about to drop the column `type` on the `Settings` table. All the data in the column will be lost.

*/
-- CreateEnum
CREATE TYPE "FrequencyType" AS ENUM ('DAILY', 'WEEKLY', 'MONTHLY', 'QUARTERLY', 'YEARLY');

-- CreateEnum
CREATE TYPE "RefundPolicyType" AS ENUM ('FULL', 'PARTIAL', 'NONE');

-- CreateEnum
CREATE TYPE "ReminderMethodType" AS ENUM ('SMS', 'EMAIL', 'IN_APP', 'PUSH', 'WHATSAPP');

-- AlterTable
ALTER TABLE "Settings" DROP COLUMN "percentageOrAmount",
DROP COLUMN "type",
ADD COLUMN     "applicationFeePercentage" DOUBLE PRECISION,
ADD COLUMN     "depositPercentage" DOUBLE PRECISION,
ADD COLUMN     "lateFeeEnabled" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "lateFeeFrequency" "FrequencyType",
ADD COLUMN     "lateFeeGracePeriod" INTEGER,
ADD COLUMN     "lateFeePercentage" DOUBLE PRECISION,
ADD COLUMN     "notificationEnabled" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "notificationFrequency" INTEGER,
ADD COLUMN     "refundPolicy" "RefundPolicyType",
ADD COLUMN     "refundTimeframe" "FrequencyType",
ADD COLUMN     "reminderMethods" "ReminderMethodType"[];
