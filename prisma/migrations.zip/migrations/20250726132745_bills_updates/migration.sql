/*
  Warnings:

  - You are about to drop the column `billId` on the `Transaction` table. All the data in the column will be lost.
  - You are about to drop the column `amount` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `billCategory` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `billFrequency` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `billId` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `billName` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `createdAt` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `dueDate` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `landlordId` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `payableBy` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `propertyId` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `tenantId` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the column `updatedAt` on the `bills` table. All the data in the column will be lost.
  - You are about to drop the `_ResidentialPropertyTobills` table. If the table is not empty, all the data it contains will be lost.
  - Added the required column `name` to the `bills` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "Transaction" DROP CONSTRAINT "Transaction_billId_fkey";

-- DropForeignKey
ALTER TABLE "_ResidentialPropertyTobills" DROP CONSTRAINT "_ResidentialPropertyTobills_A_fkey";

-- DropForeignKey
ALTER TABLE "_ResidentialPropertyTobills" DROP CONSTRAINT "_ResidentialPropertyTobills_B_fkey";

-- DropForeignKey
ALTER TABLE "bills" DROP CONSTRAINT "bills_landlordId_fkey";

-- DropForeignKey
ALTER TABLE "bills" DROP CONSTRAINT "bills_propertyId_fkey";

-- DropForeignKey
ALTER TABLE "bills" DROP CONSTRAINT "bills_tenantId_fkey";

-- DropIndex
DROP INDEX "bills_billId_key";

-- AlterTable
ALTER TABLE "Transaction" DROP COLUMN "billId";

-- AlterTable
ALTER TABLE "bills" DROP COLUMN "amount",
DROP COLUMN "billCategory",
DROP COLUMN "billFrequency",
DROP COLUMN "billId",
DROP COLUMN "billName",
DROP COLUMN "createdAt",
DROP COLUMN "dueDate",
DROP COLUMN "landlordId",
DROP COLUMN "payableBy",
DROP COLUMN "propertyId",
DROP COLUMN "tenantId",
DROP COLUMN "updatedAt",
ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "name" TEXT NOT NULL,
ALTER COLUMN "description" DROP NOT NULL;

-- DropTable
DROP TABLE "_ResidentialPropertyTobills";

-- CreateTable
CREATE TABLE "billsSubCategory" (
    "id" TEXT NOT NULL,
    "billId" TEXT NOT NULL,
    "billName" TEXT NOT NULL,
    "billCategoryId" TEXT NOT NULL,
    "description" TEXT NOT NULL,
    "amount" DECIMAL(18,2) NOT NULL,
    "billFrequency" "PaymentFrequency" NOT NULL,
    "dueDate" TIMESTAMP(3) NOT NULL,
    "payableBy" "PayableBy" DEFAULT 'LANDLORD',
    "propertyId" TEXT,
    "landlordId" TEXT,
    "tenantId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "billsSubCategory_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "_ResidentialPropertyTobillsSubCategory" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateTable
CREATE TABLE "_TransactionTobillsSubCategory" (
    "A" TEXT NOT NULL,
    "B" TEXT NOT NULL
);

-- CreateIndex
CREATE UNIQUE INDEX "billsSubCategory_billId_key" ON "billsSubCategory"("billId");

-- CreateIndex
CREATE UNIQUE INDEX "_ResidentialPropertyTobillsSubCategory_AB_unique" ON "_ResidentialPropertyTobillsSubCategory"("A", "B");

-- CreateIndex
CREATE INDEX "_ResidentialPropertyTobillsSubCategory_B_index" ON "_ResidentialPropertyTobillsSubCategory"("B");

-- CreateIndex
CREATE UNIQUE INDEX "_TransactionTobillsSubCategory_AB_unique" ON "_TransactionTobillsSubCategory"("A", "B");

-- CreateIndex
CREATE INDEX "_TransactionTobillsSubCategory_B_index" ON "_TransactionTobillsSubCategory"("B");

-- AddForeignKey
ALTER TABLE "billsSubCategory" ADD CONSTRAINT "billsSubCategory_propertyId_fkey" FOREIGN KEY ("propertyId") REFERENCES "properties"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billsSubCategory" ADD CONSTRAINT "billsSubCategory_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "billsSubCategory" ADD CONSTRAINT "billsSubCategory_billCategoryId_fkey" FOREIGN KEY ("billCategoryId") REFERENCES "bills"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_ResidentialPropertyTobillsSubCategory" ADD CONSTRAINT "_ResidentialPropertyTobillsSubCategory_A_fkey" FOREIGN KEY ("A") REFERENCES "ResidentialProperty"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_ResidentialPropertyTobillsSubCategory" ADD CONSTRAINT "_ResidentialPropertyTobillsSubCategory_B_fkey" FOREIGN KEY ("B") REFERENCES "billsSubCategory"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_TransactionTobillsSubCategory" ADD CONSTRAINT "_TransactionTobillsSubCategory_A_fkey" FOREIGN KEY ("A") REFERENCES "Transaction"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "_TransactionTobillsSubCategory" ADD CONSTRAINT "_TransactionTobillsSubCategory_B_fkey" FOREIGN KEY ("B") REFERENCES "billsSubCategory"("id") ON DELETE CASCADE ON UPDATE CASCADE;
