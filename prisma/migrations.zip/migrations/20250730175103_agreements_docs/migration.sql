/*
  Warnings:

  - You are about to drop the column `agreementDocumentUrl` on the `application` table. All the data in the column will be lost.
  - You are about to drop the column `agreementVersion` on the `application` table. All the data in the column will be lost.
  - You are about to drop the column `lastAgreementUpdate` on the `application` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "application" DROP COLUMN "agreementDocumentUrl",
DROP COLUMN "agreementVersion",
DROP COLUMN "lastAgreementUpdate";

-- CreateTable
CREATE TABLE "AgreementDocument" (
    "id" TEXT NOT NULL,
    "documentUrl" TEXT NOT NULL,
    "documentKey" TEXT NOT NULL,
    "processedContent" TEXT,
    "variables" JSONB NOT NULL,
    "metadata" JSONB,
    "sentAt" TIMESTAMP(3),
    "signedByTenantAt" TIMESTAMP(3),
    "signedByLandlordAt" TIMESTAMP(3),
    "completedAt" TIMESTAMP(3),
    "applicationId" TEXT NOT NULL,
    "templateId" TEXT NOT NULL,
    "templateVersion" INTEGER NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "createdBy" TEXT NOT NULL,

    CONSTRAINT "AgreementDocument_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "AgreementDocument_documentKey_key" ON "AgreementDocument"("documentKey");

-- AddForeignKey
ALTER TABLE "AgreementDocument" ADD CONSTRAINT "AgreementDocument_applicationId_fkey" FOREIGN KEY ("applicationId") REFERENCES "application"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AgreementDocument" ADD CONSTRAINT "AgreementDocument_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES "DocuTemplate"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
