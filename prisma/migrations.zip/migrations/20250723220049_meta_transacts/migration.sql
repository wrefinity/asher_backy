-- AlterTable
ALTER TABLE "Transaction" ADD COLUMN     "metadata" JSONB;
