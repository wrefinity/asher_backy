/*
  Warnings:

  - You are about to drop the column `companyLogoUrl` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `contactCompany` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `contactName` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `viewingArrangements` on the `properties` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "properties" DROP COLUMN "companyLogoUrl",
DROP COLUMN "contactCompany",
DROP COLUMN "contactName",
DROP COLUMN "viewingArrangements";
