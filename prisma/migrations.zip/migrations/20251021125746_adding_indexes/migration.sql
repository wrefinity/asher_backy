-- CreateIndex
CREATE INDEX "state_id_idx" ON "state"("id");

-- CreateIndex
CREATE INDEX "state_name_idx" ON "state"("name");

-- CreateIndex
CREATE INDEX "users_email_idx" ON "users"("email");

-- CreateIndex
CREATE INDEX "users_googleId_idx" ON "users"("googleId");

-- CreateIndex
CREATE INDEX "users_profileId_idx" ON "users"("profileId");
