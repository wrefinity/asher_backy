-- AlterTable
ALTER TABLE "Email" ALTER COLUMN "receiverEmail" DROP NOT NULL;
