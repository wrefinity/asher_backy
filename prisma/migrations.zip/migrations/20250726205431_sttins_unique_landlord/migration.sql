/*
  Warnings:

  - A unique constraint covering the columns `[landlordId]` on the table `Settings` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateIndex
CREATE UNIQUE INDEX "Settings_landlordId_key" ON "Settings"("landlordId");
