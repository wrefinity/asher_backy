-- DropForeignKey
ALTER TABLE "Broadcast" DROP CONSTRAINT "Broadcast_landlordId_fkey";

-- AlterTable
ALTER TABLE "BroadcastCategory" ADD COLUMN     "landlordId" TEXT;

-- AddForeignKey
ALTER TABLE "Broadcast" ADD CONSTRAINT "Broadcast_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "BroadcastCategory" ADD CONSTRAINT "BroadcastCategory_landlordId_fkey" FOREIGN KEY ("landlordId") REFERENCES "landlords"("id") ON DELETE CASCADE ON UPDATE CASCADE;
