-- AlterTable
ALTER TABLE "DocuTemplateVersion" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;
