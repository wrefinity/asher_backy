-- AlterTable
ALTER TABLE "DiscussionThread" ADD COLUMN     "likesCount" INTEGER NOT NULL DEFAULT 0;
