-- CreateEnum
CREATE TYPE "NotificationChannel" AS ENUM ('EMAIL', 'SMS', 'IN_APP', 'PUSH');

-- CreateEnum
CREATE TYPE "NotificationCategory" AS ENUM ('SECURITY', 'COMMUNICATION', 'ONLINE_PAYMENTS', 'MAINTENANCE_REQUESTS', 'MOVE_OUT', 'PROPERTY_MATCH', 'WEBSITE_INQUIRY', 'SUPPORT_TICKET', 'MARKETING_EMAILS');

-- CreateTable
CREATE TABLE "NotificationPreference" (
    "id" TEXT NOT NULL,
    "category" "NotificationCategory" NOT NULL,
    "notifyOnLoginActivity" BOOLEAN NOT NULL DEFAULT true,
    "notifyOnNewMessages" BOOLEAN NOT NULL DEFAULT true,
    "notifyPaymentInitiated" BOOLEAN NOT NULL DEFAULT true,
    "notifyPaymentSuccess" BOOLEAN NOT NULL DEFAULT true,
    "notifyPaymentFailed" BOOLEAN NOT NULL DEFAULT true,
    "notifyNewMaintenanceRequest" BOOLEAN NOT NULL DEFAULT true,
    "notifyRequestStatusChange" BOOLEAN NOT NULL DEFAULT true,
    "notifyRequestMessage" BOOLEAN NOT NULL DEFAULT true,
    "notifyRequestResolved" BOOLEAN NOT NULL DEFAULT true,
    "notifyNewInvoice" BOOLEAN NOT NULL DEFAULT true,
    "notifyTenantMoveOut" BOOLEAN NOT NULL DEFAULT true,
    "notifyPropertyMatch" BOOLEAN NOT NULL DEFAULT true,
    "notifyNewInquiry" BOOLEAN NOT NULL DEFAULT true,
    "notifyNewSupportTicket" BOOLEAN NOT NULL DEFAULT true,
    "receiveMarketingEmails" BOOLEAN NOT NULL DEFAULT true,
    "channels" "NotificationChannel"[],
    "userId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "NotificationPreference_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "NotificationPreference_userId_category_key" ON "NotificationPreference"("userId", "category");

-- AddForeignKey
ALTER TABLE "NotificationPreference" ADD CONSTRAINT "NotificationPreference_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
