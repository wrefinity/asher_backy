-- AlterTable
ALTER TABLE "Forum" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;
