-- AlterTable
ALTER TABLE "Event" ALTER COLUMN "vendorId" DROP NOT NULL;
