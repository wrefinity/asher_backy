-- AlterTable
ALTER TABLE "Email" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;
