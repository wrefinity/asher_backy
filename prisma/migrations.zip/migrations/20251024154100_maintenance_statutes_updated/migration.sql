-- AlterTable
ALTER TABLE "maintenanceStatusHistory" ADD COLUMN     "vendorId" TEXT;

-- CreateTable
CREATE TABLE "maintenanceAssignmentHistory" (
    "id" TEXT NOT NULL,
    "maintenanceId" TEXT NOT NULL,
    "vendorId" TEXT,
    "assignedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "unassignedAt" TIMESTAMP(3),
    "reasonLeft" TEXT,
    "state" "maintenanceStatus" NOT NULL DEFAULT 'ASSIGNED',

    CONSTRAINT "maintenanceAssignmentHistory_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ChatRoom_user1Id_updatedAt_idx" ON "ChatRoom"("user1Id", "updatedAt");

-- CreateIndex
CREATE INDEX "ChatRoom_user2Id_updatedAt_idx" ON "ChatRoom"("user2Id", "updatedAt");

-- CreateIndex
CREATE INDEX "ChatRoom_maintenanceId_idx" ON "ChatRoom"("maintenanceId");

-- CreateIndex
CREATE INDEX "ChatRoom_createdAt_idx" ON "ChatRoom"("createdAt");

-- CreateIndex
CREATE INDEX "ChatRoom_updatedAt_idx" ON "ChatRoom"("updatedAt");

-- CreateIndex
CREATE INDEX "ChatRoom_user1Id_updatedAt_id_idx" ON "ChatRoom"("user1Id", "updatedAt", "id");

-- CreateIndex
CREATE INDEX "ChatRoom_user2Id_updatedAt_id_idx" ON "ChatRoom"("user2Id", "updatedAt", "id");

-- CreateIndex
CREATE INDEX "ChatRoom_user1Id_user2Id_updatedAt_idx" ON "ChatRoom"("user1Id", "user2Id", "updatedAt");

-- CreateIndex
CREATE INDEX "Email_senderId_createdAt_idx" ON "Email"("senderId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_receiverId_createdAt_idx" ON "Email"("receiverId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_senderId_isDeleted_createdAt_idx" ON "Email"("senderId", "isDeleted", "createdAt");

-- CreateIndex
CREATE INDEX "Email_receiverId_isDeleted_createdAt_idx" ON "Email"("receiverId", "isDeleted", "createdAt");

-- CreateIndex
CREATE INDEX "Email_threadId_createdAt_idx" ON "Email"("threadId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_parentEmailId_idx" ON "Email"("parentEmailId");

-- CreateIndex
CREATE INDEX "Email_createdAt_idx" ON "Email"("createdAt");

-- CreateIndex
CREATE INDEX "Email_senderEmail_idx" ON "Email"("senderEmail");

-- CreateIndex
CREATE INDEX "Email_receiverEmail_idx" ON "Email"("receiverEmail");

-- CreateIndex
CREATE INDEX "Email_isDraft_senderId_idx" ON "Email"("isDraft", "senderId");

-- CreateIndex
CREATE INDEX "Email_isSent_senderId_idx" ON "Email"("isSent", "senderId");

-- CreateIndex
CREATE INDEX "Email_isArchived_senderId_createdAt_idx" ON "Email"("isArchived", "senderId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_isArchived_receiverId_createdAt_idx" ON "Email"("isArchived", "receiverId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_isSpam_receiverId_createdAt_idx" ON "Email"("isSpam", "receiverId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_isStarred_senderId_createdAt_idx" ON "Email"("isStarred", "senderId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_isStarred_receiverId_createdAt_idx" ON "Email"("isStarred", "receiverId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_isReadByReceiver_receiverId_createdAt_idx" ON "Email"("isReadByReceiver", "receiverId", "createdAt");

-- CreateIndex
CREATE INDEX "Email_receiverId_isDeleted_isSpam_isArchived_createdAt_idx" ON "Email"("receiverId", "isDeleted", "isSpam", "isArchived", "createdAt");

-- CreateIndex
CREATE INDEX "Email_senderId_isDeleted_isDraft_isSent_createdAt_idx" ON "Email"("senderId", "isDeleted", "isDraft", "isSent", "createdAt");

-- CreateIndex
CREATE INDEX "Email_threadId_createdAt_id_idx" ON "Email"("threadId", "createdAt", "id");

-- CreateIndex
CREATE INDEX "Message_chatRoomId_createdAt_idx" ON "Message"("chatRoomId", "createdAt");

-- CreateIndex
CREATE INDEX "Message_senderId_createdAt_idx" ON "Message"("senderId", "createdAt");

-- CreateIndex
CREATE INDEX "Message_receiverId_createdAt_idx" ON "Message"("receiverId", "createdAt");

-- CreateIndex
CREATE INDEX "Message_createdAt_idx" ON "Message"("createdAt");

-- CreateIndex
CREATE INDEX "Message_chatRoomId_senderId_createdAt_idx" ON "Message"("chatRoomId", "senderId", "createdAt");

-- CreateIndex
CREATE INDEX "Message_chatType_createdAt_idx" ON "Message"("chatType", "createdAt");

-- CreateIndex
CREATE INDEX "Message_chatRoomId_createdAt_id_idx" ON "Message"("chatRoomId", "createdAt", "id");

-- CreateIndex
CREATE INDEX "UserEmailState_userId_isRead_isDeleted_idx" ON "UserEmailState"("userId", "isRead", "isDeleted");

-- CreateIndex
CREATE INDEX "UserEmailState_userId_isStarred_isDeleted_idx" ON "UserEmailState"("userId", "isStarred", "isDeleted");

-- CreateIndex
CREATE INDEX "UserEmailState_userId_isArchived_isDeleted_idx" ON "UserEmailState"("userId", "isArchived", "isDeleted");

-- CreateIndex
CREATE INDEX "UserEmailState_userId_isSpam_isDeleted_idx" ON "UserEmailState"("userId", "isSpam", "isDeleted");

-- CreateIndex
CREATE INDEX "UserEmailState_userId_isDraft_idx" ON "UserEmailState"("userId", "isDraft");

-- CreateIndex
CREATE INDEX "UserEmailState_emailId_idx" ON "UserEmailState"("emailId");

-- CreateIndex
CREATE INDEX "UserEmailState_userId_isDeleted_idx" ON "UserEmailState"("userId", "isDeleted");

-- CreateIndex
CREATE INDEX "UserEmailState_userId_isRead_isArchived_isSpam_isDeleted_idx" ON "UserEmailState"("userId", "isRead", "isArchived", "isSpam", "isDeleted");

-- CreateIndex
CREATE INDEX "UserEmailState_userId_isStarred_isRead_isDeleted_idx" ON "UserEmailState"("userId", "isStarred", "isRead", "isDeleted");

-- CreateIndex
CREATE INDEX "maintenance_vendorId_idx" ON "maintenance"("vendorId");

-- CreateIndex
CREATE INDEX "maintenance_status_idx" ON "maintenance"("status");

-- AddForeignKey
ALTER TABLE "maintenanceStatusHistory" ADD CONSTRAINT "maintenanceStatusHistory_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenanceAssignmentHistory" ADD CONSTRAINT "maintenanceAssignmentHistory_maintenanceId_fkey" FOREIGN KEY ("maintenanceId") REFERENCES "maintenance"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "maintenanceAssignmentHistory" ADD CONSTRAINT "maintenanceAssignmentHistory_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE SET NULL ON UPDATE CASCADE;
