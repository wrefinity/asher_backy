-- AlterEnum
ALTER TYPE "PropertyType" ADD VALUE 'FLAT';
