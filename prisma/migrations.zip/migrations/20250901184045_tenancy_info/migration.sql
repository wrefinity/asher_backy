-- AlterTable
ALTER TABLE "tenants" ADD COLUMN     "applicationQuestions" JSONB,
ADD COLUMN     "declarationInfo" JSONB,
ADD COLUMN     "emergencyContactInfo" JSONB,
ADD COLUMN     "employmentInfo" JSONB,
ADD COLUMN     "guarantorInfo" JSONB,
ADD COLUMN     "nextOfKinInfo" JSONB,
ADD COLUMN     "personalInfo" JSONB,
ADD COLUMN     "residentialInfo" JSONB;
