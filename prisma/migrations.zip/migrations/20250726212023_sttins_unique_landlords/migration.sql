-- DropIndex
DROP INDEX "Settings_landlordId_key";
