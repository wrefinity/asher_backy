-- CreateTable
CREATE TABLE "DocuTemplate" (
    "id" TEXT NOT NULL,
    "title" TEXT NOT NULL,
    "description" TEXT,
    "content" JSONB NOT NULL,
    "ownerId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isActive" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "DocuTemplate_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DocuTemplateVersion" (
    "id" TEXT NOT NULL,
    "templateId" TEXT NOT NULL,
    "version" INTEGER NOT NULL,
    "content" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedBy" TEXT NOT NULL,

    CONSTRAINT "DocuTemplateVersion_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "UserDocuTemplate" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "templateId" TEXT NOT NULL,
    "isDefault" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "UserDocuTemplate_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "DocuTemplateVersion_templateId_version_key" ON "DocuTemplateVersion"("templateId", "version");

-- CreateIndex
CREATE UNIQUE INDEX "UserDocuTemplate_userId_templateId_key" ON "UserDocuTemplate"("userId", "templateId");

-- AddForeignKey
ALTER TABLE "DocuTemplate" ADD CONSTRAINT "DocuTemplate_ownerId_fkey" FOREIGN KEY ("ownerId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DocuTemplateVersion" ADD CONSTRAINT "DocuTemplateVersion_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES "DocuTemplate"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DocuTemplateVersion" ADD CONSTRAINT "DocuTemplateVersion_updatedBy_fkey" FOREIGN KEY ("updatedBy") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserDocuTemplate" ADD CONSTRAINT "UserDocuTemplate_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "UserDocuTemplate" ADD CONSTRAINT "UserDocuTemplate_templateId_fkey" FOREIGN KEY ("templateId") REFERENCES "DocuTemplate"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
