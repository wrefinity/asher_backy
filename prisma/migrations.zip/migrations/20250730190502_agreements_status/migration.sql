-- CreateEnum
CREATE TYPE "AgreementStatus" AS ENUM ('SIGNED_BY_TENANT', 'SIGNED_BY_LANDLORD');

-- AlterTable
ALTER TABLE "AgreementDocument" ADD COLUMN     "agreementStatus" "AgreementStatus";
