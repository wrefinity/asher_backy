/*
  Warnings:

  - You are about to drop the column `likesCount` on the `Comment` table. All the data in the column will be lost.
  - You are about to drop the column `usersId` on the `CommentLike` table. All the data in the column will be lost.
  - A unique constraint covering the columns `[commentId,userId]` on the table `CommentLike` will be added. If there are existing duplicate values, this will fail.
  - Added the required column `isLike` to the `CommentLike` table without a default value. This is not possible if the table is not empty.
  - Added the required column `userId` to the `CommentLike` table without a default value. This is not possible if the table is not empty.

*/
-- DropForeignKey
ALTER TABLE "CommentLike" DROP CONSTRAINT "CommentLike_usersId_fkey";

-- DropIndex
DROP INDEX "CommentLike_commentId_usersId_key";

-- AlterTable
ALTER TABLE "Comment" DROP COLUMN "likesCount";

-- AlterTable
ALTER TABLE "CommentLike" DROP COLUMN "usersId",
ADD COLUMN     "isLike" BOOLEAN NOT NULL,
ADD COLUMN     "userId" TEXT NOT NULL;

-- CreateIndex
CREATE UNIQUE INDEX "CommentLike_commentId_userId_key" ON "CommentLike"("commentId", "userId");

-- AddForeignKey
ALTER TABLE "CommentLike" ADD CONSTRAINT "CommentLike_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
