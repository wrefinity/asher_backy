-- AlterTable
ALTER TABLE "Email" ADD COLUMN     "isReply" BOOLEAN NOT NULL DEFAULT false;
