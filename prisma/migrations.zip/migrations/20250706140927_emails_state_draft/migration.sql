-- AlterTable
ALTER TABLE "UserEmailState" ADD COLUMN     "isDraft" BOOLEAN NOT NULL DEFAULT false;
