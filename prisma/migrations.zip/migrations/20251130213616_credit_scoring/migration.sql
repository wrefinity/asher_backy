-- AlterTable
ALTER TABLE "creditScore" ADD COLUMN     "bonusPoints" INTEGER DEFAULT 0,
ADD COLUMN     "communication" DOUBLE PRECISION,
ADD COLUMN     "dataQuality" TEXT,
ADD COLUMN     "financialBehavior" DOUBLE PRECISION,
ADD COLUMN     "penaltyPoints" INTEGER DEFAULT 0,
ADD COLUMN     "propertyCare" DOUBLE PRECISION,
ADD COLUMN     "scoreBreakdown" JSONB;

-- CreateIndex
CREATE INDEX "creditScore_score_idx" ON "creditScore"("score");

-- CreateIndex
CREATE INDEX "creditScore_lastUpdated_idx" ON "creditScore"("lastUpdated");
