-- CreateTable
CREATE TABLE "profileDocument" (
    "id" TEXT NOT NULL,
    "url" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "profileId" TEXT NOT NULL,

    CONSTRAINT "profileDocument_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "profileDocument_profileId_idx" ON "profileDocument"("profileId");

-- AddForeignKey
ALTER TABLE "profileDocument" ADD CONSTRAINT "profileDocument_profileId_fkey" FOREIGN KEY ("profileId") REFERENCES "profile"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
