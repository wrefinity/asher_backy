-- AlterTable
ALTER TABLE "Community" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;
