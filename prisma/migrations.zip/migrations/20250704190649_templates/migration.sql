-- AlterEnum
ALTER TYPE "TransactionReference" ADD VALUE 'TRANSFER';
