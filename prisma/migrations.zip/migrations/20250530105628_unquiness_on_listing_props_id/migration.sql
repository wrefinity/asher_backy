-- DropIndex
DROP INDEX "propertyListingHistory_propertyId_key";
