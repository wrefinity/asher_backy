-- CreateEnum
CREATE TYPE "QuoteStatus" AS ENUM ('PENDING', 'ACCEPTED', 'REJECTED', 'EXPIRED');

-- CreateTable
CREATE TABLE "MaintenanceQuote" (
    "id" TEXT NOT NULL,
    "maintenanceId" TEXT NOT NULL,
    "vendorId" TEXT NOT NULL,
    "amount" DECIMAL(18,2) NOT NULL,
    "description" TEXT,
    "breakdown" JSONB,
    "attachments" TEXT[],
    "status" "QuoteStatus" NOT NULL DEFAULT 'PENDING',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "isDeleted" BOOLEAN NOT NULL DEFAULT false,

    CONSTRAINT "MaintenanceQuote_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "MaintenanceQuote_maintenanceId_idx" ON "MaintenanceQuote"("maintenanceId");

-- CreateIndex
CREATE INDEX "MaintenanceQuote_vendorId_idx" ON "MaintenanceQuote"("vendorId");

-- CreateIndex
CREATE INDEX "MaintenanceQuote_status_idx" ON "MaintenanceQuote"("status");

-- CreateIndex
CREATE UNIQUE INDEX "MaintenanceQuote_maintenanceId_vendorId_key" ON "MaintenanceQuote"("maintenanceId", "vendorId");

-- AddForeignKey
ALTER TABLE "MaintenanceQuote" ADD CONSTRAINT "MaintenanceQuote_maintenanceId_fkey" FOREIGN KEY ("maintenanceId") REFERENCES "maintenance"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "MaintenanceQuote" ADD CONSTRAINT "MaintenanceQuote_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
