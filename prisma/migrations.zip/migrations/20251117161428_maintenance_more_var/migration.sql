-- AlterTable
ALTER TABLE "maintenance" ADD COLUMN     "destinationReached" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "jobStarted" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "timeSpent" TEXT;
