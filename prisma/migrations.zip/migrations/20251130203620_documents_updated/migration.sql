-- AlterTable
ALTER TABLE "propertyDocument" ADD COLUMN     "isPublished" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "systemId" TEXT,
ADD COLUMN     "views" INTEGER NOT NULL DEFAULT 0;

-- CreateIndex
CREATE INDEX "propertyDocument_systemId_idx" ON "propertyDocument"("systemId");

-- CreateIndex
CREATE INDEX "propertyDocument_isPublished_idx" ON "propertyDocument"("isPublished");

-- CreateIndex
CREATE INDEX "propertyDocument_views_idx" ON "propertyDocument"("views");
