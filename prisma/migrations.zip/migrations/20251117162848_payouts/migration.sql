/*
  Warnings:

  - A unique constraint covering the columns `[stripeTokenId]` on the table `bankInfo` will be added. If there are existing duplicate values, this will fail.

*/
-- CreateEnum
CREATE TYPE "PayoutStatus" AS ENUM ('PENDING', 'IN_TRANSIT', 'PAID', 'CANCELED', 'FAILED', 'REVERSED');

-- AlterEnum
ALTER TYPE "TransactionReference" ADD VALUE 'PAYOUT';

-- AlterTable
ALTER TABLE "bankInfo" ADD COLUMN     "accountHolderType" TEXT,
ADD COLUMN     "accountNumberLast4" TEXT,
ADD COLUMN     "country" TEXT,
ADD COLUMN     "createdAt" TIMESTAMP(3) DEFAULT CURRENT_TIMESTAMP,
ADD COLUMN     "currency" "Currency",
ADD COLUMN     "isDefault" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "isVerified" BOOLEAN NOT NULL DEFAULT false,
ADD COLUMN     "routingNumber" TEXT,
ADD COLUMN     "sortCode" TEXT,
ADD COLUMN     "stripeTokenId" TEXT,
ADD COLUMN     "updatedAt" TIMESTAMP(3),
ADD COLUMN     "verificationStatus" TEXT;

-- CreateTable
CREATE TABLE "Payout" (
    "id" TEXT NOT NULL,
    "stripePayoutId" TEXT NOT NULL,
    "vendorId" TEXT NOT NULL,
    "amount" DECIMAL(18,2) NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'USD',
    "status" "PayoutStatus" NOT NULL DEFAULT 'PENDING',
    "destination" TEXT NOT NULL,
    "description" TEXT,
    "failureCode" TEXT,
    "failureMessage" TEXT,
    "failureBalanceTransaction" TEXT,
    "arrivalDate" TIMESTAMP(3),
    "method" TEXT NOT NULL,
    "sourceType" TEXT NOT NULL,
    "automatic" BOOLEAN NOT NULL DEFAULT true,
    "livemode" BOOLEAN NOT NULL DEFAULT false,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    "metadata" JSONB,

    CONSTRAINT "Payout_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "PayoutTransaction" (
    "id" TEXT NOT NULL,
    "payoutId" TEXT NOT NULL,
    "transactionId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "PayoutTransaction_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "Payout_stripePayoutId_key" ON "Payout"("stripePayoutId");

-- CreateIndex
CREATE INDEX "Payout_vendorId_idx" ON "Payout"("vendorId");

-- CreateIndex
CREATE INDEX "Payout_stripePayoutId_idx" ON "Payout"("stripePayoutId");

-- CreateIndex
CREATE INDEX "Payout_status_idx" ON "Payout"("status");

-- CreateIndex
CREATE INDEX "Payout_createdAt_idx" ON "Payout"("createdAt");

-- CreateIndex
CREATE INDEX "PayoutTransaction_payoutId_idx" ON "PayoutTransaction"("payoutId");

-- CreateIndex
CREATE INDEX "PayoutTransaction_transactionId_idx" ON "PayoutTransaction"("transactionId");

-- CreateIndex
CREATE UNIQUE INDEX "PayoutTransaction_payoutId_transactionId_key" ON "PayoutTransaction"("payoutId", "transactionId");

-- CreateIndex
CREATE UNIQUE INDEX "bankInfo_stripeTokenId_key" ON "bankInfo"("stripeTokenId");

-- CreateIndex
CREATE INDEX "bankInfo_vendorId_idx" ON "bankInfo"("vendorId");

-- CreateIndex
CREATE INDEX "bankInfo_isDefault_idx" ON "bankInfo"("isDefault");

-- AddForeignKey
ALTER TABLE "Payout" ADD CONSTRAINT "Payout_vendorId_fkey" FOREIGN KEY ("vendorId") REFERENCES "vendors"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PayoutTransaction" ADD CONSTRAINT "PayoutTransaction_payoutId_fkey" FOREIGN KEY ("payoutId") REFERENCES "Payout"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "PayoutTransaction" ADD CONSTRAINT "PayoutTransaction_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES "Transaction"("id") ON DELETE CASCADE ON UPDATE CASCADE;
