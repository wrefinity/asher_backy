-- AddForeignKey
ALTER TABLE "billsSubCategory" ADD CONSTRAINT "billsSubCategory_tenantId_fkey" FOREIGN KEY ("tenantId") REFERENCES "tenants"("id") ON DELETE SET NULL ON UPDATE CASCADE;
