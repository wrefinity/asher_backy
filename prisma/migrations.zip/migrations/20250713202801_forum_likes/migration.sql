-- CreateTable
CREATE TABLE "ForumThreadLike" (
    "id" TEXT NOT NULL,
    "threadId" TEXT NOT NULL,
    "usersId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ForumThreadLike_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "ForumThreadLike_threadId_usersId_key" ON "ForumThreadLike"("threadId", "usersId");

-- AddForeignKey
ALTER TABLE "ForumThreadLike" ADD CONSTRAINT "ForumThreadLike_threadId_fkey" FOREIGN KEY ("threadId") REFERENCES "DiscussionThread"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ForumThreadLike" ADD CONSTRAINT "ForumThreadLike_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
