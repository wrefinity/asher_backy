/*
  Warnings:

  - Made the column `email` on table `applicantPersonalDetails` required. This step will fail if there are existing NULL values in that column.

*/
-- DropIndex
DROP INDEX "applicantPersonalDetails_email_idx";

-- AlterTable
ALTER TABLE "applicantPersonalDetails" ALTER COLUMN "email" SET NOT NULL;
