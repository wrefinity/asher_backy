-- CreateIndex
CREATE INDEX "AgreementDocument_applicationId_idx" ON "AgreementDocument"("applicationId");

-- CreateIndex
CREATE INDEX "AgreementDocument_templateId_templateVersion_idx" ON "AgreementDocument"("templateId", "templateVersion");

-- CreateIndex
CREATE INDEX "AgreementDocument_agreementStatus_idx" ON "AgreementDocument"("agreementStatus");

-- CreateIndex
CREATE INDEX "AgreementDocument_createdAt_idx" ON "AgreementDocument"("createdAt");

-- CreateIndex
CREATE INDEX "AgreementDocument_sentAt_idx" ON "AgreementDocument"("sentAt");

-- CreateIndex
CREATE INDEX "AgreementDocument_completedAt_idx" ON "AgreementDocument"("completedAt");

-- CreateIndex
CREATE INDEX "EmploymentInformation_userId_idx" ON "EmploymentInformation"("userId");

-- CreateIndex
CREATE INDEX "EmploymentInformation_employerCompany_idx" ON "EmploymentInformation"("employerCompany");

-- CreateIndex
CREATE INDEX "EmploymentInformation_employerEmail_idx" ON "EmploymentInformation"("employerEmail");

-- CreateIndex
CREATE INDEX "EmploymentInformation_employerPhone_idx" ON "EmploymentInformation"("employerPhone");

-- CreateIndex
CREATE INDEX "EmploymentInformation_monthlyOrAnualIncome_idx" ON "EmploymentInformation"("monthlyOrAnualIncome");

-- CreateIndex
CREATE INDEX "EmploymentInformation_startDate_idx" ON "EmploymentInformation"("startDate");

-- CreateIndex
CREATE INDEX "LeaseRenewal_status_proposedAt_idx" ON "LeaseRenewal"("status", "proposedAt");

-- CreateIndex
CREATE INDEX "LeaseRenewal_proposedAt_idx" ON "LeaseRenewal"("proposedAt");

-- CreateIndex
CREATE INDEX "LeaseRenewal_createdAt_idx" ON "LeaseRenewal"("createdAt");

-- CreateIndex
CREATE INDEX "PrevAddress_residentialInformationId_idx" ON "PrevAddress"("residentialInformationId");

-- CreateIndex
CREATE INDEX "applicantPersonalDetails_userId_idx" ON "applicantPersonalDetails"("userId");

-- CreateIndex
CREATE INDEX "applicantPersonalDetails_email_idx" ON "applicantPersonalDetails"("email");

-- CreateIndex
CREATE INDEX "applicantPersonalDetails_phoneNumber_idx" ON "applicantPersonalDetails"("phoneNumber");

-- CreateIndex
CREATE INDEX "applicantPersonalDetails_identificationNo_idx" ON "applicantPersonalDetails"("identificationNo");

-- CreateIndex
CREATE INDEX "applicantPersonalDetails_lastName_firstName_idx" ON "applicantPersonalDetails"("lastName", "firstName");

-- CreateIndex
CREATE INDEX "application_userId_status_isDeleted_idx" ON "application"("userId", "status", "isDeleted");

-- CreateIndex
CREATE INDEX "application_propertiesId_status_isDeleted_idx" ON "application"("propertiesId", "status", "isDeleted");

-- CreateIndex
CREATE INDEX "application_status_createdAt_idx" ON "application"("status", "createdAt");

-- CreateIndex
CREATE INDEX "application_userId_createdAt_idx" ON "application"("userId", "createdAt");

-- CreateIndex
CREATE INDEX "application_isDeleted_status_idx" ON "application"("isDeleted", "status");

-- CreateIndex
CREATE INDEX "application_moveInDate_idx" ON "application"("moveInDate");

-- CreateIndex
CREATE INDEX "application_leaseStartDate_leaseEndDate_idx" ON "application"("leaseStartDate", "leaseEndDate");

-- CreateIndex
CREATE INDEX "application_createdAt_idx" ON "application"("createdAt");

-- CreateIndex
CREATE INDEX "application_updatedAt_idx" ON "application"("updatedAt");

-- CreateIndex
CREATE INDEX "application_applicationInviteId_idx" ON "application"("applicationInviteId");

-- CreateIndex
CREATE INDEX "application_userId_status_isDeleted_createdAt_idx" ON "application"("userId", "status", "isDeleted", "createdAt");

-- CreateIndex
CREATE INDEX "applicationInvites_propertiesId_isDeleted_idx" ON "applicationInvites"("propertiesId", "isDeleted");

-- CreateIndex
CREATE INDEX "applicationInvites_tenantsId_isDeleted_idx" ON "applicationInvites"("tenantsId", "isDeleted");

-- CreateIndex
CREATE INDEX "applicationInvites_userInvitedId_response_idx" ON "applicationInvites"("userInvitedId", "response");

-- CreateIndex
CREATE INDEX "applicationInvites_invitedByLandordId_createdAt_idx" ON "applicationInvites"("invitedByLandordId", "createdAt");

-- CreateIndex
CREATE INDEX "applicationInvites_createdAt_idx" ON "applicationInvites"("createdAt");

-- CreateIndex
CREATE INDEX "applicationInvites_response_isDeleted_idx" ON "applicationInvites"("response", "isDeleted");

-- CreateIndex
CREATE INDEX "applicationInvites_scheduleDate_idx" ON "applicationInvites"("scheduleDate");

-- CreateIndex
CREATE INDEX "applicationQuestions_applicantId_idx" ON "applicationQuestions"("applicantId");

-- CreateIndex
CREATE INDEX "applicationQuestions_havePet_idx" ON "applicationQuestions"("havePet");

-- CreateIndex
CREATE INDEX "applicationQuestions_youSmoke_idx" ON "applicationQuestions"("youSmoke");

-- CreateIndex
CREATE INDEX "applicationQuestions_requireParking_idx" ON "applicationQuestions"("requireParking");

-- CreateIndex
CREATE INDEX "applicationQuestions_haveOutstandingDebts_idx" ON "applicationQuestions"("haveOutstandingDebts");

-- CreateIndex
CREATE INDEX "declaration_applicantId_idx" ON "declaration"("applicantId");

-- CreateIndex
CREATE INDEX "declaration_date_idx" ON "declaration"("date");

-- CreateIndex
CREATE INDEX "emergencyContact_userId_idx" ON "emergencyContact"("userId");

-- CreateIndex
CREATE INDEX "emergencyContact_email_idx" ON "emergencyContact"("email");

-- CreateIndex
CREATE INDEX "emergencyContact_phoneNumber_idx" ON "emergencyContact"("phoneNumber");

-- CreateIndex
CREATE INDEX "guarantorInformation_userId_idx" ON "guarantorInformation"("userId");

-- CreateIndex
CREATE INDEX "guarantorInformation_email_idx" ON "guarantorInformation"("email");

-- CreateIndex
CREATE INDEX "guarantorInformation_phoneNumber_idx" ON "guarantorInformation"("phoneNumber");

-- CreateIndex
CREATE INDEX "guarantorInformation_identificationNo_idx" ON "guarantorInformation"("identificationNo");

-- CreateIndex
CREATE INDEX "guarantorInformation_fullName_idx" ON "guarantorInformation"("fullName");

-- CreateIndex
CREATE INDEX "nextOfKin_applicantPersonalDetailsId_idx" ON "nextOfKin"("applicantPersonalDetailsId");

-- CreateIndex
CREATE INDEX "nextOfKin_email_idx" ON "nextOfKin"("email");

-- CreateIndex
CREATE INDEX "nextOfKin_phoneNumber_idx" ON "nextOfKin"("phoneNumber");

-- CreateIndex
CREATE INDEX "nextOfKin_lastName_firstName_idx" ON "nextOfKin"("lastName", "firstName");

-- CreateIndex
CREATE INDEX "referees_userId_idx" ON "referees"("userId");

-- CreateIndex
CREATE INDEX "referees_personalEmail_idx" ON "referees"("personalEmail");

-- CreateIndex
CREATE INDEX "referees_professionalEmail_idx" ON "referees"("professionalEmail");

-- CreateIndex
CREATE INDEX "referees_personalPhoneNumber_idx" ON "referees"("personalPhoneNumber");

-- CreateIndex
CREATE INDEX "referees_professionalPhoneNumber_idx" ON "referees"("professionalPhoneNumber");

-- CreateIndex
CREATE INDEX "residentialInformation_userId_idx" ON "residentialInformation"("userId");

-- CreateIndex
CREATE INDEX "residentialInformation_city_state_idx" ON "residentialInformation"("city", "state");

-- CreateIndex
CREATE INDEX "residentialInformation_zipCode_idx" ON "residentialInformation"("zipCode");
