-- AlterTable
ALTER TABLE "properties" ADD COLUMN     "isListed" BOOLEAN NOT NULL DEFAULT false;
