-- AlterTable
ALTER TABLE "violation" ADD COLUMN     "status" "ViolationStatus" DEFAULT 'PENDING';
