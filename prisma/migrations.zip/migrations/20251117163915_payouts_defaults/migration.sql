-- AlterTable
ALTER TABLE "bankInfo" ALTER COLUMN "currency" SET DEFAULT 'USD';
