-- CreateTable
CREATE TABLE "DiscussionCommentShare" (
    "id" TEXT NOT NULL,
    "commentId" TEXT NOT NULL,
    "usersId" TEXT NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "DiscussionCommentShare_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "DiscussionCommentShare_commentId_usersId_key" ON "DiscussionCommentShare"("commentId", "usersId");

-- AddForeignKey
ALTER TABLE "DiscussionCommentShare" ADD CONSTRAINT "DiscussionCommentShare_commentId_fkey" FOREIGN KEY ("commentId") REFERENCES "DiscussionComment"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionCommentShare" ADD CONSTRAINT "DiscussionCommentShare_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
