-- AlterTable
ALTER TABLE "DiscussionThread" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;

-- CreateTable
CREATE TABLE "ForumMember" (
    "id" TEXT NOT NULL,
    "forumId" TEXT NOT NULL,
    "usersId" TEXT NOT NULL,
    "role" TEXT NOT NULL DEFAULT 'MEMBER',
    "status" "MembershipStatus" NOT NULL DEFAULT 'MEMBER',
    "joinedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "ForumMember_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DiscussionThreadPoll" (
    "id" TEXT NOT NULL,
    "threadId" TEXT NOT NULL,
    "question" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "DiscussionThreadPoll_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DiscussionThreadPollOption" (
    "id" TEXT NOT NULL,
    "pollId" TEXT NOT NULL,
    "option" TEXT NOT NULL,
    "votes" INTEGER NOT NULL DEFAULT 0,

    CONSTRAINT "DiscussionThreadPollOption_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "DiscussionThreadPollVote" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "optionId" TEXT NOT NULL,

    CONSTRAINT "DiscussionThreadPollVote_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "ForumMember_usersId_idx" ON "ForumMember"("usersId");

-- CreateIndex
CREATE INDEX "ForumMember_status_idx" ON "ForumMember"("status");

-- CreateIndex
CREATE UNIQUE INDEX "ForumMember_forumId_usersId_key" ON "ForumMember"("forumId", "usersId");

-- CreateIndex
CREATE UNIQUE INDEX "DiscussionThreadPoll_threadId_key" ON "DiscussionThreadPoll"("threadId");

-- CreateIndex
CREATE INDEX "DiscussionThreadPoll_threadId_idx" ON "DiscussionThreadPoll"("threadId");

-- CreateIndex
CREATE INDEX "DiscussionThreadPollOption_pollId_idx" ON "DiscussionThreadPollOption"("pollId");

-- CreateIndex
CREATE UNIQUE INDEX "DiscussionThreadPollVote_userId_optionId_key" ON "DiscussionThreadPollVote"("userId", "optionId");

-- AddForeignKey
ALTER TABLE "ForumMember" ADD CONSTRAINT "ForumMember_forumId_fkey" FOREIGN KEY ("forumId") REFERENCES "Forum"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "ForumMember" ADD CONSTRAINT "ForumMember_usersId_fkey" FOREIGN KEY ("usersId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionThreadPoll" ADD CONSTRAINT "DiscussionThreadPoll_threadId_fkey" FOREIGN KEY ("threadId") REFERENCES "DiscussionThread"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionThreadPollOption" ADD CONSTRAINT "DiscussionThreadPollOption_pollId_fkey" FOREIGN KEY ("pollId") REFERENCES "DiscussionThreadPoll"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionThreadPollVote" ADD CONSTRAINT "DiscussionThreadPollVote_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "DiscussionThreadPollVote" ADD CONSTRAINT "DiscussionThreadPollVote_optionId_fkey" FOREIGN KEY ("optionId") REFERENCES "DiscussionThreadPollOption"("id") ON DELETE RESTRICT ON UPDATE CASCADE;
