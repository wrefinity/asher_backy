/*
  Warnings:

  - You are about to drop the column `parkingSpaces` on the `ResidentialProperty` table. All the data in the column will be lost.
  - You are about to drop the column `petPolicy` on the `ResidentialProperty` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "ResidentialProperty" DROP COLUMN "parkingSpaces",
DROP COLUMN "petPolicy";
