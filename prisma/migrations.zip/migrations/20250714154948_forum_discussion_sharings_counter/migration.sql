-- AlterTable
ALTER TABLE "DiscussionComment" ADD COLUMN     "shareCount" INTEGER NOT NULL DEFAULT 0;
