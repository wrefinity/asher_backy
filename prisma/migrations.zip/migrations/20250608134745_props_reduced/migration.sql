/*
  Warnings:

  - You are about to drop the column `amenityDistances` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `customNearbyAmenities` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `initialDeposit` on the `properties` table. All the data in the column will be lost.
  - You are about to drop the column `nearbyAmenities` on the `properties` table. All the data in the column will be lost.

*/
-- AlterEnum
-- This migration adds more than one value to an enum.
-- With PostgreSQL versions 11 and earlier, this is not possible
-- in a single migration. This can be worked around by creating
-- multiple migrations, each migration adding only one value to
-- the enum.


ALTER TYPE "ViolationStatus" ADD VALUE 'ESCALATED';
ALTER TYPE "ViolationStatus" ADD VALUE 'DELIVERED';

-- AlterTable
ALTER TABLE "properties" DROP COLUMN "amenityDistances",
DROP COLUMN "customNearbyAmenities",
DROP COLUMN "initialDeposit",
DROP COLUMN "nearbyAmenities";

-- AlterTable
ALTER TABLE "violation" ADD COLUMN     "amount" DECIMAL(18,2) DEFAULT 0.00;
