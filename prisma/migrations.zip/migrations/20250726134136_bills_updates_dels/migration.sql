-- AlterTable
ALTER TABLE "billsSubCategory" ADD COLUMN     "isDeleted" BOOLEAN NOT NULL DEFAULT false;
