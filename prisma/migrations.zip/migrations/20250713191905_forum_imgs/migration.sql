-- AlterTable
ALTER TABLE "DiscussionThread" ADD COLUMN     "imageUrl" TEXT[];

-- AlterTable
ALTER TABLE "Forum" ADD COLUMN     "imageUrl" TEXT[];
