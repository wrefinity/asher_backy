/*
  Warnings:

  - You are about to drop the column `documentKey` on the `AgreementDocument` table. All the data in the column will be lost.
  - The `documentUrl` column on the `AgreementDocument` table would be dropped and recreated. This will lead to data loss if there is data in the column.

*/
-- DropIndex
DROP INDEX "AgreementDocument_documentKey_key";

-- AlterTable
ALTER TABLE "AgreementDocument" DROP COLUMN "documentKey",
DROP COLUMN "documentUrl",
ADD COLUMN     "documentUrl" TEXT[];
